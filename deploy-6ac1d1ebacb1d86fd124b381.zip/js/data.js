/**
 * DRAGON MALA - Initial Seed Data & LocalStorage Store
 */

const STORAGE_KEYS = {
    QUEUES: 'dragon_mala_queues',
    USERS: 'dragon_mala_users',
    CURRENT_USER: 'dragon_mala_current_user',
    PROMOTIONS: 'dragon_mala_promotions',
    MENUS: 'dragon_mala_menus',
    SOUPS: 'dragon_mala_soups',
    TABLES: 'dragon_mala_tables',
    STORE_CONFIG: 'dragon_mala_config'
};
const SEED_CLEANUP_KEY = 'dragon_mala_seed_cleanup_v2';
const TABLE_RESTORE_KEY = 'dragon_mala_table_restore_v1';
const DATABASE_STORE_KEYS = new Set([
    STORAGE_KEYS.QUEUES,
    STORAGE_KEYS.USERS,
    STORAGE_KEYS.PROMOTIONS,
    STORAGE_KEYS.MENUS,
    STORAGE_KEYS.SOUPS,
    STORAGE_KEYS.TABLES,
    STORAGE_KEYS.STORE_CONFIG
]);

function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    }[character]));
}

// Initial Promotions (หน้าหลักบอกโปรต่างๆ)
const INITIAL_PROMOTIONS = [
    {
        id: 'promo-1',
        title: '🔥 บุฟเฟต์หมาล่าพรีเมียม ลดทันที 20%',
        category: 'buffet',
        tag: 'HOT DEAL',
        discount: 'ลด 20%',
        period: 'วันนี้ - 31 ต.ค. 2026',
        desc: 'อิ่มไม่อั้นกับเนื้อวากิวออสเตรเลีย ไส้เป็ดเสฉวน และกุ้งสดเด้ง พร้อมน้ำซุป 4 ช่อง ฟรีไม่อั้นตลอด 2 ชั่วโมงเต็ม',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop',
        code: 'MALAVIP20',
        featured: true
    },
    {
        id: 'promo-2',
        title: '👑 สมาชิกใหม่ รับฟรี! ซุปหมาล่านมสดพรีเมียม',
        category: 'member',
        tag: 'MEMBER EXCLUSIVE',
        discount: 'ฟรีซุป 1 หม้อ',
        period: 'สิทธิ์ตลอดปี 2026',
        desc: 'เพียงสมัครสมาชิกผ่านอีเมลวันนี้ รับทันทีคูปองฟรีน้ำซุปหมาล่านมสด มูลค่า 399.- พร้อมสิทธิ์โปรโมชั่นพิเศษ',
        image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=800&auto=format&fit=crop',
        code: 'FREESOUP2026',
        featured: true
    },
    {
        id: 'promo-3',
        title: '🍲 เซ็ตมังกรทองคู่ (สำหรับ 2-3 ท่าน) เพียง 699.-',
        category: 'discount',
        tag: 'COMBO SET',
        discount: 'ราคาพิเศษ 699.-',
        period: 'จันทร์ - ศุกร์ ทั้งวัน',
        desc: 'ชุดรวมเนื้อริบอายสไลซ์, หมูสามชั้นคุโรบูตะ, ลูกชิ้นกุ้งทำสด, ฟองเต้าหู้ทอดกรอบ และผักรวมเพื่อสุขภาพ',
        image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=800&auto=format&fit=crop',
        code: 'COMBO699',
        featured: true
    },
    {
        id: 'promo-4',
        title: '🌙 Happy Late Night หมาล่ารอบดึก ลด 15%',
        category: 'discount',
        tag: 'LATE NIGHT',
        discount: 'ลด 15%',
        period: 'ทุกวัน 22:00 - 02:00 น.',
        desc: 'เอาใจสายตี้และคนนอนดึก ลดทันที 15% ทุกเมนูอาหารเมื่อเปิดโต๊ะหลัง 4 ทุ่มเป็นต้นไป',
        image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=800&auto=format&fit=crop',
        code: 'NIGHT15',
        featured: false
    },
    {
        id: 'promo-5',
        title: '🎂 ฉลองวันเกิด รับฟรีเซ็ตเนื้อเค้กหมาล่า',
        category: 'member',
        tag: 'BIRTHDAY',
        discount: 'ฟรีเค้กเนื้อ',
        period: 'ภายในเดือนเกิด',
        desc: 'สมาชิกที่มาทานในเดือนเกิด รับเค้กเนื้อสไลซ์รูปหัวใจมูลค่า 450.- ฟรี พร้อมถ่ายรูปโพลารอยด์เป็นที่ระลึก',
        image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=800&auto=format&fit=crop',
        code: 'BDAYMALA',
        featured: false
    },
    {
        id: 'promo-6',
        title: '🍻 บุฟเฟต์เครื่องดื่มรีฟิล + บาร์น้ำจิ้มไม่อั้น 39.-',
        category: 'buffet',
        tag: 'UNLIMITED',
        discount: 'เพียง 39.-',
        period: 'ตลอดปี 2026',
        desc: 'ปรุงน้ำจิ้มสูตรเด็ดได้ไม่จำกัดกว่า 25 ชนิด พร้อมชาฟักเขียวเสฉวน, เก๊กฮวยหิมะ และน้ำสมุนไพรจีน',
        image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=800&auto=format&fit=crop',
        code: 'REFILL39',
        featured: false
    }
];

// Initial Soups
const INITIAL_SOUPS = [
    {
        id: 'soup-1',
        name: 'ซุปหมาล่าเสฉวนมันวัว',
        sub: 'Sichuan Spicy Beef Tallow',
        level: 'เผ็ดชาเลเวล 5/5',
        desc: 'สูตรต้นตำรับแท้ มันวัวแท้หอมกรุ่นเคี่ยวพริกเสฉวนและฮวาเจียว รสชาติเข้มข้น ดุดัน ถึงใจ',
        price: 199,
        badge: 'สูตรลับยอดนิยม',
        icon: 'fa-pepper-hot text-red-500'
    },
    {
        id: 'soup-2',
        name: 'ซุปหมาล่านมสดพรีเมียม',
        sub: 'Creamy Mala Milk Soup',
        level: 'เผ็ดชาเลเวล 3/5',
        desc: 'ผสานความเผ็ดชาของหมาล่ากับความนุ่มละมุนของนมสดฮอกไกโด รสชาติกลมกล่อม ซดคล่องคอ',
        price: 199,
        badge: 'ซิกเนเจอร์อันดับ 1',
        icon: 'fa-droplet text-amber-300'
    },
    {
        id: 'soup-3',
        name: 'ซุปกระดูกหมูคอลลาเจน',
        sub: 'Pork Bone Collagen Soup',
        level: 'ไม่เผ็ด (ละมุนกลมกล่อม)',
        desc: 'เคี่ยวกระดูกหมูนานกว่า 12 ชั่วโมง จนได้น้ำซุปสีขาวนวล อุดมไปด้วยคอลลาเจนและสมุนไพรจีนบำรุงสุขภาพ',
        price: 159,
        badge: 'เพื่อสุขภาพ',
        icon: 'fa-bowl-rice text-slate-300'
    },
    {
        id: 'soup-4',
        name: 'ซุปมะเขือเทศเข้มข้น',
        sub: 'Rich Tomato Broth',
        level: 'ไม่เผ็ด (เปรี้ยวหวานกลมกล่อม)',
        desc: 'ทำจากมะเขือเทศสดสายพันธุ์หวานนำเข้า ให้รสเปรี้ยวอมหวานสดชื่น เข้ากับเนื้อสไลซ์ได้อย่างลงตัว',
        price: 159,
        badge: 'เด็กทานได้',
        icon: 'fa-seedling text-red-400'
    }
];

// Initial Ingredients Showcase
const INITIAL_INGREDIENTS = [
    { name: 'เนื้อริบอายวากิว A5', price: '380.-', img: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=400&auto=format&fit=crop' },
    { name: 'ไส้เป็ดเสฉวนกรุบกรอบ', price: '160.-', img: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=400&auto=format&fit=crop' },
    { name: 'ลูกชิ้นกุ้งปั้นสดไข่กุ้ง', price: '190.-', img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=400&auto=format&fit=crop' },
    { name: 'หมูสามชั้นคุโรบูตะ', price: '180.-', img: 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?q=80&w=400&auto=format&fit=crop' },
    { name: 'ฟองเต้าหู้ทอดม้วนกรอบ', price: '95.-', img: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400&auto=format&fit=crop' },
    { name: 'เส้นมันเทศหนึบหนับ', price: '60.-', img: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?q=80&w=400&auto=format&fit=crop' }
];

// Initial Menu Management Items (สำหรับระบบหลังบ้าน)
const INITIAL_MENUS = [
    { id: 'm-1', name: 'เนื้อวากิวออสเตรเลียริบอาย', category: 'meat', price: 380, status: 'available', stock: 50 },
    { id: 'm-2', name: 'หมูสามชั้นคุโรบูตะสไลซ์', category: 'pork', price: 180, status: 'available', stock: 80 },
    { id: 'm-3', name: 'ไส้เป็ดเสฉวนนำเข้า', category: 'special', price: 160, status: 'available', stock: 40 },
    { id: 'm-4', name: 'ลูกชิ้นกุ้งสดไข่กุ้งลาวา', category: 'seafood', price: 190, status: 'available', stock: 65 },
    { id: 'm-5', name: 'กุ้งแม่น้ำแกะเปลือก', category: 'seafood', price: 220, status: 'available', stock: 30 },
    { id: 'm-6', name: 'ฟองเต้าหู้ม้วนทอดกรอบ', category: 'veggie', price: 95, status: 'available', stock: 100 },
    { id: 'm-7', name: 'เส้นมันหนึบสไตล์จีน', category: 'noodles', price: 60, status: 'available', stock: 120 },
    { id: 'm-8', name: 'เลือดเป็ดตุ๋นสมุนไพร', category: 'special', price: 80, status: 'available', stock: 45 },
    { id: 'm-9', name: 'ซุปหมาล่าเสฉวนมันวัว', category: 'soup', price: 199, status: 'available', stock: 999 },
    { id: 'm-10', name: 'ซุปหมาล่านมสดพรีเมียม', category: 'soup', price: 199, status: 'available', stock: 999 }
];

// Initial System Users (ลูกค้า สมาชิก พนักงาน เจ้าของร้าน)
const INITIAL_USERS = [
    {
        id: 'u-owner',
        name: 'เฮียตี๋ (เจ้าของร้าน / ผู้บริหาร)',
        email: 'owner@dragonmala.com',
        phone: '0811112222',
        password: 'password123',
        role: 'owner', // owner, staff, customer
        created_at: '2026-01-01'
    },
    {
        id: 'u-staff',
        name: 'สมศักดิ์ (หัวหน้าพนักงานหน้าร้าน)',
        email: 'staff@dragonmala.com',
        phone: '0822223333',
        password: 'password123',
        role: 'staff',
        created_at: '2026-01-15'
    },
];

const INITIAL_TABLES = [
    { id: 'T01', name: 'โต๊ะ A1 (1-2 คน)', type: 'A', seats: 2, status: 'available', currentQueue: null },
    { id: 'T02', name: 'โต๊ะ A2 (1-2 คน)', type: 'A', seats: 2, status: 'available', currentQueue: null },
    { id: 'T03', name: 'โต๊ะ A3 (1-2 คน)', type: 'A', seats: 2, status: 'available', currentQueue: null },
    { id: 'T04', name: 'โต๊ะ A4 (1-2 คน)', type: 'A', seats: 2, status: 'available', currentQueue: null },
    { id: 'T05', name: 'โต๊ะ A5 (1-2 คน)', type: 'A', seats: 2, status: 'available', currentQueue: null },
    { id: 'T06', name: 'โต๊ะ B1 (3-4 คน)', type: 'B', seats: 4, status: 'available', currentQueue: null },
    { id: 'T07', name: 'โต๊ะ B2 (3-4 คน)', type: 'B', seats: 4, status: 'available', currentQueue: null },
    { id: 'T08', name: 'โต๊ะ B3 (3-4 คน)', type: 'B', seats: 4, status: 'available', currentQueue: null },
    { id: 'T09', name: 'โต๊ะ B4 (3-4 คน)', type: 'B', seats: 4, status: 'available', currentQueue: null },
    { id: 'T10', name: 'โต๊ะ C1 (5-8 คน)', type: 'C', seats: 8, status: 'available', currentQueue: null },
    { id: 'T11', name: 'โต๊ะ C2 (5-8 คน)', type: 'C', seats: 8, status: 'available', currentQueue: null },
    { id: 'T12', name: 'โต๊ะ C3 (5-8 คน)', type: 'C', seats: 8, status: 'available', currentQueue: null },
    { id: 'T13', name: 'ห้อง VIP 1 (9+ คน)', type: 'V', seats: 12, status: 'available', currentQueue: null },
    { id: 'T14', name: 'ห้อง VIP 2 (9+ คน)', type: 'V', seats: 16, status: 'available', currentQueue: null }
];

// Initial Queues Data (รายการจองจริง - เริ่มต้นไม่มีคิวเดโม)
const INITIAL_QUEUES = [];

// Initial Store Configuration
const INITIAL_CONFIG = {
    storeName: 'DRAGON MALA',
    branchName: 'DRAGON MALA สาขาหลัก สยามสแควร์วัน (ชั้น 4)',
    phone: '02-123-4567',
    isQueueOpen: true,
    avgWaitPerQueueMinutes: 6,
    openHours: '11:00 - 02:00 น.',
    announcement: 'สมัครสมาชิกใหม่วันนี้ รับฟรี! ซุปหมาล่านมสดพรีเมียม 1 หม้อ'
};

// Data Store Helper Functions
const Store = {
    init() {
        if (this.get(STORAGE_KEYS.PROMOTIONS) === null) {
            this.set(STORAGE_KEYS.PROMOTIONS, INITIAL_PROMOTIONS);
        }
        if (this.get(STORAGE_KEYS.SOUPS) === null) {
            this.set(STORAGE_KEYS.SOUPS, INITIAL_SOUPS);
        }
        if (this.get(STORAGE_KEYS.QUEUES) === null) {
            this.set(STORAGE_KEYS.QUEUES, INITIAL_QUEUES);
        } else {
            // ล้างข้อมูลคิวเดโมเดิมออกหากมีอยู่ใน LocalStorage เพื่อให้เป็นรายการคิวจริงทั้งหมด
            const existing = this.get(STORAGE_KEYS.QUEUES);
            if (Array.isArray(existing)) {
                const hasDemo = existing.some(q => q.id === 'q-a12' || q.id === 'q-a13' || q.id === 'q-a14' || q.id === 'q-b8' || q.id === 'q-b9' || q.id === 'q-c3' || q.id === 'q-c4' || q.id === 'q-v1');
                if (hasDemo) {
                    this.saveQueues([]);
                    this.saveTables(INITIAL_TABLES);
                }
            }
        }
        if (this.get(STORAGE_KEYS.USERS) === null) {
            this.set(STORAGE_KEYS.USERS, INITIAL_USERS);
        }
        if (this.get(STORAGE_KEYS.TABLES) === null) {
            this.set(STORAGE_KEYS.TABLES, INITIAL_TABLES);
        }
        if (this.get(STORAGE_KEYS.MENUS) === null) {
            this.set(STORAGE_KEYS.MENUS, INITIAL_MENUS);
        }
        if (this.get(STORAGE_KEYS.STORE_CONFIG) === null) {
            this.set(STORAGE_KEYS.STORE_CONFIG, INITIAL_CONFIG);
        }

        if (!localStorage.getItem(SEED_CLEANUP_KEY)) {
            const users = this.getUsers();
            if (Array.isArray(users)) {
                const realUsers = users.filter(user => user.id !== 'u-customer');
                this.saveUsers(realUsers);
            }

            const tables = this.getTables();
            const legacyTableIds = new Set([
                'T01', 'T02', 'T03', 'T04', 'T05', 'T06', 'T07',
                'T08', 'T09', 'T10', 'T11', 'T12', 'T13', 'T14'
            ]);
            const isLegacyDemoTables = Array.isArray(tables) &&
                tables.length === legacyTableIds.size &&
                tables.every(table => legacyTableIds.has(table.id) && !table.currentQueue);
            if (isLegacyDemoTables) this.saveTables([]);

            const currentUser = this.getCurrentUser();
            if (currentUser && currentUser.id === 'u-customer') this.logoutUser();
            localStorage.setItem(SEED_CLEANUP_KEY, '1');
        }

        if (!localStorage.getItem(TABLE_RESTORE_KEY)) {
            const tables = this.getTables();
            if (Array.isArray(tables) && tables.length === 0) this.saveTables(INITIAL_TABLES);
            localStorage.setItem(TABLE_RESTORE_KEY, '1');
        }
    },

    get(key) {
        if (DATABASE_STORE_KEYS.has(key)) {
            try {
                const request = new XMLHttpRequest();
                request.open('GET', `/api/store?key=${encodeURIComponent(key)}`, false);
                request.send();
                if (request.status === 200) return JSON.parse(request.responseText).value;
                if (request.status === 404) {
                    const legacyValue = localStorage.getItem(key);
                    if (legacyValue !== null) {
                        const parsedValue = JSON.parse(legacyValue);
                        this.set(key, parsedValue);
                        return parsedValue;
                    }
                }
            } catch (e) {
                console.error('Error reading database key:', key, e);
            }
            return null;
        }

        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            console.error('Error reading storage key:', key, e);
            return null;
        }
    },

    set(key, val) {
        if (DATABASE_STORE_KEYS.has(key)) {
            try {
                const request = new XMLHttpRequest();
                request.open('POST', `/api/store?key=${encodeURIComponent(key)}`, false);
                request.setRequestHeader('Content-Type', 'application/json');
                request.send(JSON.stringify({ value: val }));
                if (request.status >= 200 && request.status < 300) return;
            } catch (e) {
                console.error('Error setting database key:', key, e);
            }
            return;
        }

        try {
            localStorage.setItem(key, JSON.stringify(val));
        } catch (e) {
            console.error('Error setting storage key:', key, e);
        }
    },

    // Specific Getters & Helpers
    getQueues() {
        return this.get(STORAGE_KEYS.QUEUES) || INITIAL_QUEUES;
    },

    saveQueues(queues) {
        this.set(STORAGE_KEYS.QUEUES, queues);
    },

    getUsers() {
        return this.get(STORAGE_KEYS.USERS) || INITIAL_USERS;
    },

    saveUsers(users) {
        this.set(STORAGE_KEYS.USERS, users);
    },

    getCurrentUser() {
        return this.get(STORAGE_KEYS.CURRENT_USER);
    },

    setCurrentUser(user) {
        this.set(STORAGE_KEYS.CURRENT_USER, user);
    },

    logoutUser() {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    },

    getPromotions() {
        return this.get(STORAGE_KEYS.PROMOTIONS) || INITIAL_PROMOTIONS;
    },

    savePromotions(promos) {
        this.set(STORAGE_KEYS.PROMOTIONS, promos);
    },

    getSoups() {
        return this.get(STORAGE_KEYS.SOUPS) || INITIAL_SOUPS;
    },

    saveSoups(soups) {
        this.set(STORAGE_KEYS.SOUPS, soups);
    },

    getTables() {
        return this.get(STORAGE_KEYS.TABLES) || INITIAL_TABLES;
    },

    saveTables(tables) {
        this.set(STORAGE_KEYS.TABLES, tables);
    },

    getMenus() {
        return this.get(STORAGE_KEYS.MENUS) || INITIAL_MENUS;
    },

    saveMenus(menus) {
        this.set(STORAGE_KEYS.MENUS, menus);
    },

    getConfig() {
        return this.get(STORAGE_KEYS.STORE_CONFIG) || INITIAL_CONFIG;
    },

    saveConfig(cfg) {
        this.set(STORAGE_KEYS.STORE_CONFIG, cfg);
    }
};

// Initialize default store
Store.init();
