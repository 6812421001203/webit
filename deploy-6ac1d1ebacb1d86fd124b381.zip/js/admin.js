/**
 * DRAGON MALA - Admin & Staff Portal Controller
 */

let isVoiceEnabled = true;
let currentFilterType = 'all';
let currentSeatingQueueId = null;
let hourlyChartInstance = null;
let tableTypeChartInstance = null;
let lastKnownWaitingCount = 0;

if (typeof window.showToast !== 'function') {
    window.showToast = function(title, message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;
        const toast = document.createElement('div');
        const color = type === 'success' ? 'border-emerald-500 text-emerald-200' : type === 'error' ? 'border-red-500 text-red-200' : 'border-amber-500 text-amber-200';
        toast.className = `toast-item pointer-events-auto p-4 rounded-2xl border bg-[#200808]/95 shadow-2xl max-w-sm ${color}`;
        toast.innerHTML = `<strong class="block text-sm text-white">${escapeHtml(title)}</strong><span class="text-xs">${escapeHtml(message)}</span>`;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 4500);
    };
}

document.addEventListener('DOMContentLoaded', () => {
    if (!ensureAdminAuth()) return;
    initAdminTabs();
    renderAllAdminSections();
    
    // Listen for Real-time Storage Events across browser tabs/windows
    window.addEventListener('storage', (e) => {
        if (!e.key || e.key === STORAGE_KEYS.QUEUES || e.key === STORAGE_KEYS.TABLES || e.key === STORAGE_KEYS.CURRENT_USER) {
            renderDashboardMetrics();
            renderAdminQueues();
            renderTablesManagement();
        }
    });

    // Auto refresh queue table & dashboard metrics every 3 seconds for instant sync
    setInterval(() => {
        renderDashboardMetrics();
        renderAdminQueues();
        renderTablesManagement();
    }, 3000);
});

// Auth Guard
function isOwner() {
    const user = Store.getCurrentUser();
    return user && user.role === 'owner';
}

function isAdminUser() {
    const user = Store.getCurrentUser();
    return user && (user.role === 'owner' || user.role === 'staff');
}

function ensureAdminAuth() {
    const user = Store.getCurrentUser();
    const loginModal = document.getElementById('admin-login-modal');

    if (!user || (user.role !== 'owner' && user.role !== 'staff')) {
        if (loginModal) {
            loginModal.classList.remove('hidden');
            return false;
        } else {
            window.location.replace('index.html?auth=login&redirect=admin');
            return false;
        }
    }

    if (loginModal) {
        loginModal.classList.add('hidden');
    }

    // Update Header info
    if (document.getElementById('admin-avatar')) {
        document.getElementById('admin-avatar').innerText = user.name ? user.name.charAt(0).toUpperCase() : 'A';
    }
    if (document.getElementById('admin-user-name')) {
        document.getElementById('admin-user-name').innerText = user.name;
    }
    const roleMap = {
        owner: 'สิทธิ์: 👑 เจ้าของร้าน (Owner - สิทธิ์เต็ม)',
        staff: 'สิทธิ์: 👨‍🍳 พนักงานหน้าร้าน (แก้ไขคิวและตั้งค่ารับจองได้)',
        customer: 'สิทธิ์: 👤 สมาชิกทั่วไป'
    };
    if (document.getElementById('admin-user-role')) {
        document.getElementById('admin-user-role').innerText = roleMap[user.role] || user.role;
    }
    return true;
}

function handleAdminLogin(e) {
    e.preventDefault();
    const email = document.getElementById('admin-login-email').value.trim().toLowerCase();
    const password = document.getElementById('admin-login-password').value;

    const users = Store.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email && u.password === password);

    if (!user) {
        showToast('เข้าสู่ระบบไม่สำเร็จ', 'อีเมลหรือรหัสผ่านไม่ถูกต้อง', 'error');
        return;
    }

    if (user.role !== 'owner' && user.role !== 'staff') {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'บัญชีนี้ไม่มีสิทธิ์เข้าสู่ระบบหลังบ้าน (เฉพาะพนักงานและเ��้าของร้าน)', 'error');
        return;
    }

    Store.setCurrentUser(user);
    ensureAdminAuth();
    initAdminTabs();
    renderAllAdminSections();
    showToast('เข้าสู่ระบบสำเร็จ', `ยินดีต้อนรับ ${user.name} เข้าสู่ระบบจัดการหลังบ้าน`, 'success');
}

function quickAdminLogin(role) {
    const users = Store.getUsers();
    let target = users.find(u => u.role === role);
    if (!target) {
        if (role === 'owner') {
            target = { id: 'u-owner', name: 'เฮียตี๋ (เจ้าของร้าน)', email: 'owner@dragonmala.com', phone: '0811112222', role: 'owner' };
        } else {
            target = { id: 'u-staff', name: 'สมศักดิ์ (พนักงาน)', email: 'staff@dragonmala.com', phone: '0822223333', role: 'staff' };
        }
    }
    Store.setCurrentUser(target);
    ensureAdminAuth();
    initAdminTabs();
    renderAllAdminSections();
    showToast('เข้าสู่ระบบสำเร็จ', `เข้าใช้งานในฐานะ ${target.name} เรียบร้อยแล้ว`, 'success');
}

function adminLogout() {
    Store.logoutUser();
    window.location.href = 'index.html';
}

// ---------------- TAB NAVIGATION ----------------
function initAdminTabs() {
    // Check URL hash if exists
    const hash = window.location.hash.replace('#', '').replace('-tab', '');
    if (['dashboard', 'queue', 'tables', 'promotions', 'menus', 'users', 'settings'].includes(hash)) {
        switchAdminTab(hash);
    } else {
        switchAdminTab('dashboard');
    }
}

function switchAdminTab(tabName) {
    // Nav link styling
    document.querySelectorAll('.admin-nav-link').forEach(btn => {
        btn.classList.remove('active', 'bg-red-900/60', 'text-amber-300');
        btn.classList.add('text-gray-200');
    });

    const activeNav = document.getElementById(`nav-tab-${tabName}`);
    if (activeNav) {
        activeNav.classList.add('active', 'bg-red-900/60', 'text-amber-300');
        activeNav.classList.remove('text-gray-200');
    }

    // Hide all tab sections
    const tabs = ['dashboard', 'queue', 'tables', 'promotions', 'menus', 'users', 'settings'];
    tabs.forEach(t => {
        const sec = document.getElementById(`tab-${t}-content`);
        if (sec) sec.classList.add('hidden');
    });

    // Show target section
    const targetSec = document.getElementById(`tab-${tabName}-content`);
    if (targetSec) targetSec.classList.remove('hidden');

    // Update Titles
    const titles = {
        dashboard: { title: 'ภาพรวมร้าน & สถิติ (Dashboard)', desc: 'สรุปผลการดำเนินงาน ข้อมูลคิวสด และสถานะโต๊ะอาหาร' },
        queue: { title: 'จัดการคิวสดหน้าร้าน (Live Queue)', desc: 'เรียกคิว จัดโต๊ะ ข้ามคิว และรับคิว Walk-in' },
        tables: { title: 'ผังโต๊ะอาหาร (Table Management)', desc: 'ตรวจสอบและปรับเปลี่ยนสถานะโต๊ะทั้งหมดในร้าน' },
        promotions: { title: 'จัดการโปรโมชั่น (Promotions)', desc: 'เพิ่ม ลบ แก้ไข โปรโมชั่นและส่วนลดพิเศษสำหรับลูกค้า' },
        menus: { title: 'จัดการเมนู & วัตถุดิบ (Menu Stock)', desc: 'ควบคุมสถานะความพร้อมเสิร์ฟของน้ำซุปและอาหาร' },
        users: { title: 'สมาชิก & พนักงานร้าน (Users)', desc: 'จัดการรายชื่อผู้ใช้งานและกำหนดสิทธิ์เข้าถึงระบบ' },
        settings: { title: 'ตั้งค่าระบบร้านค้า (Settings)', desc: 'ปรับแต่งการทำงานของร้านและระบบรับคิว' }
    };

    if (titles[tabName]) {
        document.getElementById('admin-page-title').innerHTML = `<i class="fa-solid fa-gauge-high text-amber-400 mr-2"></i> ${titles[tabName].title}`;
        document.getElementById('admin-page-desc').innerText = titles[tabName].desc;
    }

    // Render Tab Data
    if (tabName === 'dashboard') renderDashboardMetrics();
    else if (tabName === 'queue') renderAdminQueues();
    else if (tabName === 'tables') renderTablesManagement();
    else if (tabName === 'promotions') renderAdminPromotions();
    else if (tabName === 'menus') renderAdminMenus();
    else if (tabName === 'users') renderAdminUsers();
    else if (tabName === 'settings') renderStoreSettings();
}

// ---------------- RENDER ALL SECTIONS ----------------
function renderAllAdminSections() {
    renderDashboardMetrics();
    renderAdminQueues();
    renderTablesManagement();
    renderAdminPromotions();
    renderAdminMenus();
    renderAdminUsers();
    renderStoreSettings();
}

// ==================== 1. DASHBOARD & CHARTS ====================
function renderDashboardMetrics() {
    const queues = Store.getQueues();
    const tables = Store.getTables();

    const waitingCount = queues.filter(q => q.status === 'waiting').length;
    const completedCount = queues.filter(q => q.status === 'completed' || q.status === 'seated').length;
    const availTables = tables.filter(t => t.status === 'available').length;

    // Toast & sound alert if new queue arrived
    if (waitingCount > lastKnownWaitingCount && lastKnownWaitingCount !== 0) {
        playChimeSound();
        const latestWaiting = queues.filter(q => q.status === 'waiting');
        const newest = latestWaiting[latestWaiting.length - 1];
        if (newest) {
            showToast('มีคิวใหม่เข้ามา!', `คิว ${newest.queueNumber} (${newest.customerName || 'ลูกค้า'}) ทำการจองเข้ามาแล้ว`, 'info');
        }
    }
    lastKnownWaitingCount = waitingCount;

    // Badges
    if (document.getElementById('dash-waiting-count')) {
        document.getElementById('dash-waiting-count').innerText = waitingCount;
    }
    if (document.getElementById('dash-avail-tables')) {
        document.getElementById('dash-avail-tables').innerText = `${availTables} / ${tables.length}`;
    }
    if (document.getElementById('dash-total-tables')) {
        document.getElementById('dash-total-tables').innerText = tables.length;
    }
    if (document.getElementById('dash-completed-count')) {
        document.getElementById('dash-completed-count').innerText = completedCount;
    }
    if (document.getElementById('dash-avg-wait')) {
        document.getElementById('dash-avg-wait').innerText = waitingCount > 0 ? `~${waitingCount * 5} นาที` : 'พร้อมบริการ';
    }
    if (document.getElementById('sidebar-waiting-badge')) {
        document.getElementById('sidebar-waiting-badge').innerText = waitingCount;
    }

    // Table Counts by Type
    const statA = tables.filter(t => t.type === 'A' && t.status === 'occupied').length;
    const statB = tables.filter(t => t.type === 'B' && t.status === 'occupied').length;
    const statC = tables.filter(t => t.type === 'C' && t.status === 'occupied').length;
    const statV = tables.filter(t => t.type === 'V' && t.status === 'occupied').length;

    if (document.getElementById('stat-a')) document.getElementById('stat-a').innerText = `${statA} โต๊ะ`;
    if (document.getElementById('stat-b')) document.getElementById('stat-b').innerText = `${statB} โต๊ะ`;
    if (document.getElementById('stat-c')) document.getElementById('stat-c').innerText = `${statC} โต๊ะ`;
    if (document.getElementById('stat-v')) document.getElementById('stat-v').innerText = `${statV} ห้อง`;

    // Render Live Queues Container on Dashboard
    const dashLiveQueuesContainer = document.getElementById('dash-live-queues-container');
    if (dashLiveQueuesContainer) {
        const activeQueues = queues.filter(q => q.status === 'waiting' || q.status === 'calling');
        if (activeQueues.length === 0) {
            dashLiveQueuesContainer.innerHTML = `
                <div class="p-6 text-center text-gray-500 bg-[#120303] rounded-2xl border border-red-950">
                    <i class="fa-solid fa-circle-check text-2xl text-emerald-500 mb-2 block"></i>
                    <p class="text-sm font-medium text-gray-300 font-kanit">ขณะนี้ไม่มีคิวรอเรียกในระบบ</p>
                    <p class="text-xs text-gray-500 font-prompt mt-0.5">พร้อมให้บริการลูกค้าใหม่ / กดรับคิว Walk-in หน้าร้านได้ทันที</p>
                </div>
            `;
        } else {
            const soupNames = {
                'mala-classic': 'หมาล่ามันวัว',
                'mala-milk': 'หมาล่านมสด',
                'collagen-pork': 'กระดูกหมูคอลลาเจน',
                'tomato': 'มะเขือเทศ',
                'mushroom': 'เห็ดรวมสมุนไพร',
                '4-soups': 'หม้อ 4 ซุป'
            };
            dashLiveQueuesContainer.innerHTML = `
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    ${activeQueues.map(q => {
                        const isCalling = q.status === 'calling';
                        return `
                            <div class="p-4 rounded-2xl ${isCalling ? 'bg-gradient-to-r from-red-950 to-amber-950 border-2 border-amber-500' : 'bg-[#120303] border border-red-900/80'} shadow-lg transition space-y-2.5">
                                <div class="flex items-center justify-between">
                                    <span class="text-2xl font-black text-amber-400 font-kanit tracking-wide">${q.queueNumber}</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${isCalling ? 'bg-red-600 text-white animate-pulse' : 'bg-amber-950 text-amber-300 border border-amber-700'}">
                                        ${isCalling ? '📢 กำลังเรียก' : '⏳ รอคิว'}
                                    </span>
                                </div>
                                <div class="text-xs space-y-0.5 border-t border-red-900/40 pt-2">
                                    <p class="text-white font-bold flex items-center justify-between">
                                        <span>👤 ${escapeHtml(q.customerName || 'ลูกค้า')}</span>
                                        <span class="text-amber-200">Type ${escapeHtml(q.type)} (${escapeHtml(q.partySize)} ท่าน)</span>
                                    </p>
                                    <p class="text-gray-400 text-[11px] flex items-center justify-between">
                                        <span>🍲 ${soupNames[q.soup] || q.soup || 'หมาล่า'}</span>
                                        <span>⏰ ${q.createdAt ? q.createdAt.substring(11, 16) + ' น.' : '-'}</span>
                                    </p>
                                        ${q.notes ? `<p class="text-amber-400/90 text-[10px] italic truncate">📝 ${escapeHtml(q.notes)}</p>` : ''}
                                </div>
                                <div class="flex items-center gap-1.5 pt-1">
                                    ${!isCalling ? `
                                        <button onclick="callQueue('${q.id}')" class="flex-1 py-1.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 text-white font-bold rounded-xl text-xs transition shadow flex items-center justify-center gap-1">
                                            <i class="fa-solid fa-bullhorn text-[10px]"></i> เรียกคิว
                                        </button>
                                        <button onclick="openSeatTableModal('${q.id}')" class="py-1.5 px-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1" title="จัดโต๊ะ">
                                            <i class="fa-solid fa-chair text-[10px]"></i> จัดโต๊ะ
                                        </button>
                                    ` : `
                                        <button onclick="repeatCallVoice('${q.id}')" class="flex-1 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xl text-xs transition shadow flex items-center justify-center gap-1">
                                            <i class="fa-solid fa-volume-high text-[10px]"></i> เรียกซ้ำ
                                        </button>
                                        <button onclick="openSeatTableModal('${q.id}')" class="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition shadow flex items-center justify-center gap-1">
                                            <i class="fa-solid fa-chair text-[10px]"></i> จัดโต๊ะ
                                        </button>
                                        <button onclick="skipQueue('${q.id}')" class="py-1.5 px-2.5 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 rounded-xl text-xs transition" title="ข้ามคิว">
                                            <i class="fa-solid fa-forward-step"></i>
                                        </button>
                                    `}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }
    }

    // Quick Mini Tables on Dashboard
    const quickContainer = document.getElementById('dash-quick-tables');
    if (quickContainer) {
        const statusColors = {
            available: 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300',
            occupied: 'bg-red-950/80 border-red-500/50 text-red-300',
            calling: 'bg-amber-950/80 border-amber-500/50 text-amber-300',
            cleaning: 'bg-blue-950/80 border-blue-500/50 text-blue-300'
        };

        quickContainer.innerHTML = tables.map(t => `
            <div onclick="switchAdminTab('tables')" class="p-2.5 rounded-xl border text-center cursor-pointer hover:scale-105 transition font-prompt ${statusColors[t.status] || statusColors.available}">
                <p class="font-bold text-xs">${t.id}</p>
                <span class="text-[10px] block mt-0.5 opacity-90">${t.status === 'available' ? 'ว่าง' : t.status === 'occupied' ? 'กำลังทาน' : t.status === 'calling' ? 'เรียกคิว' : 'ทำความสะอาด'}</span>
            </div>
        `).join('');
    }

    // Render / Update Charts
    initDashboardCharts();
}

function initDashboardCharts() {
    // 1. Hourly Traffic Chart
    const hourlyCanvas = document.getElementById('hourlyQueueChart');
    if (hourlyCanvas && !hourlyChartInstance) {
        const ctx = hourlyCanvas.getContext('2d');
        hourlyChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['11:00', '12:00', '13:00', '14:00', '16:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00'],
                datasets: [
                    {
                        label: 'จำนวนคิวลูกค้า (คิว)',
                        data: [12, 28, 35, 18, 14, 45, 52, 48, 38, 25, 16, 8],
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.15)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 3,
                        pointBackgroundColor: '#dc2626',
                        pointBorderColor: '#fbbf24',
                        pointRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#e5e7eb', font: { family: 'Prompt', size: 11 } } }
                },
                scales: {
                    x: { ticks: { color: '#9ca3af', font: { family: 'Prompt' } }, grid: { color: '#260909' } },
                    y: { ticks: { color: '#9ca3af', font: { family: 'Prompt' } }, grid: { color: '#260909' } }
                }
            }
        });
    }

    // 2. Table Type Doughnut Chart
    const typeCanvas = document.getElementById('tableTypeChart');
    if (typeCanvas && !tableTypeChartInstance) {
        const ctx = typeCanvas.getContext('2d');
        tableTypeChartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Type A (1-2 คน)', 'Type B (3-4 คน)', 'Type C (5-8 คน)', 'Type V (VIP Room)'],
                datasets: [{
                    data: [5, 4, 3, 2],
                    backgroundColor: ['#ef4444', '#f59e0b', '#a855f7', '#10b981'],
                    borderColor: '#170505',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: '#e5e7eb', font: { family: 'Prompt', size: 10 } } }
                }
            }
        });
    }
}

// ==================== 2. LIVE QUEUE CALLER & ACTIONS ====================
function filterAdminQueues(type) {
    currentFilterType = type;
    document.querySelectorAll('.admin-q-filter').forEach(btn => {
        btn.classList.remove('active', 'bg-red-700', 'text-white');
        btn.classList.add('bg-red-950', 'text-gray-300');
    });

    event.currentTarget.classList.add('active', 'bg-red-700', 'text-white');
    event.currentTarget.classList.remove('bg-red-950', 'text-gray-300');

    renderAdminQueues();
}

function renderAdminQueues() {
    const tbody = document.getElementById('admin-queue-tbody');
    if (!tbody) return;

    let queues = Store.getQueues();
    if (currentFilterType !== 'all') {
        queues = queues.filter(q => q.type === currentFilterType);
    }

    if (queues.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="py-8 text-center text-gray-500 font-prompt">
                    <i class="fa-solid fa-inbox text-2xl mb-2 text-red-900"></i>
                    <p>ไม่มีรายการคิวในขณะนี้</p>
                </td>
            </tr>
        `;
        return;
    }

    // Sort order: calling first, then waiting, then seated, then completed/cancelled
    const priority = { calling: 1, waiting: 2, seated: 3, completed: 4, cancelled: 5 };
    queues.sort((a, b) => (priority[a.status] || 99) - (priority[b.status] || 99));

    const soupNames = {
        'mala-classic': 'ซุปหมาล่าเสฉวนมันวัว',
        'mala-milk': 'ซุปหมาล่านมสดพรีเมียม',
        'collagen-pork': 'ซุปกระดูกหมูคอลลาเจน',
        'tomato': 'ซุปมะเขือเทศเข้มข้น',
        'mushroom': 'ซุปเห็ดรวมสมุนไพร',
        '4-soups': 'หม้อ 4 ซุปมหาราช'
    };

    tbody.innerHTML = queues.map(q => {
        let statusBadge = '';
        if (q.status === 'calling') {
            statusBadge = `<span class="px-2.5 py-1 rounded-lg bg-red-600 text-white font-bold flex items-center gap-1.5 animate-pulse"><span class="w-2 h-2 rounded-full bg-white"></span> กำลังเรียกคิว</span>`;
        } else if (q.status === 'waiting') {
            statusBadge = `<span class="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-700 font-bold">รอเรียกคิว</span>`;
        } else if (q.status === 'seated') {
            statusBadge = `<span class="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold">นั่งโต๊ะ (${q.tableId || 'T01'})</span>`;
        } else if (q.status === 'completed') {
            statusBadge = `<span class="px-2.5 py-1 rounded-lg bg-gray-800 text-gray-400 font-bold">ทานเสร็จสิ้น</span>`;
        } else if (q.status === 'cancelled') {
            statusBadge = `<span class="px-2.5 py-1 rounded-lg bg-red-950 text-red-400 border border-red-900 line-through">ยกเลิก / ข้าม</span>`;
        }

        return `
            <tr class="hover:bg-red-950/40 transition">
                <td class="py-3 px-4 font-black text-amber-400 font-kanit text-base whitespace-nowrap">
                    ${escapeHtml(q.queueNumber)}
                </td>
                <td class="py-3 px-4 font-medium text-white">
                    <p class="font-bold">${escapeHtml(q.customerName)}</p>
                    <span class="text-[11px] text-gray-400"><i class="fa-solid fa-phone mr-1 text-[10px]"></i>${escapeHtml(q.customerPhone || '-')}</span>
                </td>
                <td class="py-3 px-4">
                    <span class="font-bold text-amber-200">${escapeHtml(q.partySize)} ท่าน</span>
                    <span class="block text-[10px] text-gray-400">Type ${escapeHtml(q.type)}</span>
                </td>
                <td class="py-3 px-4">
                    <p class="text-xs text-gray-200">${escapeHtml(soupNames[q.soup] || q.soup || 'หมาล่าคลาสสิก')}</p>
                    ${q.notes ? `<span class="text-[10px] text-amber-400/90 italic block">📝 ${escapeHtml(q.notes)}</span>` : ''}
                </td>
                <td class="py-3 px-4 text-gray-400 whitespace-nowrap">
                    ${q.createdAt ? q.createdAt.substring(11, 16) + ' น.' : '-'}
                </td>
                <td class="py-3 px-4 whitespace-nowrap">
                    ${statusBadge}
                </td>
                <td class="py-3 px-4 text-right whitespace-nowrap">
                    <div class="flex items-center justify-end gap-1.5">
                        ${q.status === 'waiting' ? `
                            <button onclick="callQueue('${q.id}')" class="px-2.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow" title="เรียกคิว">
                                <i class="fa-solid fa-bullhorn text-[10px]"></i> เรียก
                            </button>
                        ` : ''}

                        ${q.status === 'calling' ? `
                            <button onclick="repeatCallVoice('${q.id}')" class="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 rounded-lg text-xs font-bold transition flex items-center gap-1 shadow" title="เรียกซ้ำ">
                                <i class="fa-solid fa-volume-high text-[10px]"></i> เรียกซ้ำ
                            </button>
                            <button onclick="openSeatTableModal('${q.id}')" class="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow" title="จัดโต๊ะเข้าทาน">
                                <i class="fa-solid fa-chair text-[10px]"></i> จัดโต๊ะ
                            </button>
                            <button onclick="skipQueue('${q.id}')" class="px-2 py-1.5 bg-red-950 hover:bg-red-900 border border-red-800 text-red-300 rounded-lg text-xs transition" title="ข้า���คิว / ไม่มา">
                                <i class="fa-solid fa-forward-step"></i> ข้าม
                            </button>
                        ` : ''}

                        ${q.status === 'seated' ? `
                            <button onclick="completeQueue('${q.id}')" class="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow" title="เสร็จสิ้นการทาน">
                                <i class="fa-solid fa-check text-[10px]"></i> เสร็จสิ้น
                            </button>
                        ` : ''}

                        ${q.status !== 'completed' && q.status !== 'cancelled' ? `
                            <button onclick="deleteQueueRecord('${q.id}')" class="p-1.5 text-gray-400 hover:text-red-400 transition" title="ลบรายการ">
                                <i class="fa-solid fa-trash-can text-xs"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Call Next Queue Auto
function callNextQueueByType(type) {
    const queues = Store.getQueues();
    const nextQ = queues.find(q => q.type === type && q.status === 'waiting');
    if (!nextQ) {
        showToast('ไม่มีคิวรอ', `ขณะนี้ไม่มีคิวรอสำหรับโต๊ะประเภท ${type}`, 'warning');
        return;
    }
    callQueue(nextQ.id);
}

// Call Single Queue Action
function callQueue(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (!q) return;

    q.status = 'calling';
    q.calledAt = new Date().toISOString().replace('T', ' ').substring(0, 19);
    Store.saveQueues(queues);

    renderAdminQueues();
    renderDashboardMetrics();

    // Voice announcement (natural male Thai voice)
    announceQueueVoice(q.queueNumber);
    showToast('กำลังเรียกคิว', `เรียกคิวหมายเลข ${q.queueNumber} (${q.customerName}) แล้ว`, 'info');
}

function repeatCallVoice(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (q) {
        announceQueueVoice(q.queueNumber);
        showToast('เรียกคิวซ้ำ', `เรียกหมายเลข ${q.queueNumber} อีกครั้ง`, 'info');
    }
}

function skipQueue(queueId) {
    if (!confirm('ยืนยันการข้ามคิวนี้ (ลูกค้าไม่มาแสดงตัวภายในเวลา)?')) return;
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (q) {
        q.status = 'cancelled';
        Store.saveQueues(queues);
        renderAdminQueues();
        renderDashboardMetrics();
        showToast('ข้ามคิวแล้ว', `คิว ${q.queueNumber} ถูกปรับสถานะเป็นข้ามคิว`, 'warning');
    }
}

function deleteQueueRecord(queueId) {
    if (!confirm('ต้องการลบข้อมูลคิวนี้ออกจากระบบใช่หรือไม่?')) return;
    let queues = Store.getQueues();
    queues = queues.filter(q => q.id !== queueId);
    Store.saveQueues(queues);
    renderAdminQueues();
    renderDashboardMetrics();
    showToast('ลบสำเร็จ', 'ลบข้อมูลคิวเรียบร้อยแล้ว', 'info');
}

// ---------------- VOICE ANNOUNCEMENT (THAI TTS & CHIME) ----------------
function playChimeSound() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5

        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + 0.6);
    } catch (e) {
        console.log('AudioContext error:', e);
    }
}

function announceQueueVoice(queueNumber) {
    if (!isVoiceEnabled) return;

    playChimeSound();

    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        setTimeout(() => {
            // Split letters and numbers for natural Thai speech
            const parts = queueNumber.split('-');
            const letter = parts[0];
            const numStr = parts[1] || '';
            const number = parseInt(numStr, 10) || numStr;

            const thaiLetterMap = { A: 'เอ', B: 'บี', C: 'ซี', V: 'วี ไอ พี' };
            const spokenLetter = thaiLetterMap[letter] || letter;

            // Use a short pause between the queue code and number for clearer speech.
            const text = `ขอเชิญ คิว ${spokenLetter} ${number} ครับ กรุณามาที่เคาน์เตอร์ครับ`;
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'th-TH';
            utterance.rate = 0.74;
            utterance.pitch = 0.82;
            utterance.volume = 1;

            // Prefer an installed Thai male voice. Voice names vary by operating system.
            const voices = window.speechSynthesis.getVoices();
            const thaiVoices = voices.filter(v => v.lang === 'th-TH' || v.lang.startsWith('th'));
            const maleVoice = thaiVoices.find(v => {
                const name = v.name.toLowerCase();
                return name.includes('male') || name.includes('natt') || name.includes('thana') || name.includes('chai');
            });
            utterance.voice = maleVoice || thaiVoices[0];

            window.speechSynthesis.speak(utterance);
        }, 400);
    }
}

function toggleVoiceAnnouncement() {
    isVoiceEnabled = !isVoiceEnabled;
    const btnText = document.getElementById('voice-status-text');
    const toggleBtn = document.getElementById('voice-toggle-btn');
    if (isVoiceEnabled) {
        btnText.innerText = 'เสียงเรียกคิว: เปิด';
        toggleBtn.classList.remove('opacity-60');
        showToast('เปิดเสียงเรียกคิว', 'ระบบจะส่งเสียงและพูดภาษาไทยเมื่อเรียกคิว', 'info');
    } else {
        btnText.innerText = 'เสียงเรียกคิว: ปิด';
        toggleBtn.classList.add('opacity-60');
        showToast('ปิดเสียงเรียกคิว', 'ปิดการส่งเสียงพูดเรียบร้อยแล้ว', 'info');
    }
}

// ---------------- SEATING CUSTOMER TO TABLE ----------------
function openSeatTableModal(queueId) {
    currentSeatingQueueId = queueId;
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (!q) return;

    document.getElementById('seat-queue-info').innerText = `กำลังจัดคิว ${q.queueNumber} (${q.customerName}) - จำนวน ${q.partySize} ท่าน`;

    const tables = Store.getTables();
    const requiredSeats = { '1-2': 2, '3-4': 4, '5-8': 8, '9+': 9 }[q.partySize] || 2;
    const availableTables = tables.filter(t =>
        t.status === 'available' &&
        t.seats >= requiredSeats &&
        t.type === q.type
    );
    const container = document.getElementById('seat-available-tables-list');

    if (availableTables.length === 0) {
        container.innerHTML = `
            <div class="col-span-2 text-center py-4 text-red-400 font-prompt">
                <i class="fa-solid fa-triangle-exclamation text-xl mb-1"></i>
                <p>ขณะนี้ไม่มีโต๊ะว่างในร้าน!</p>
                <p class="text-[11px] text-gray-400 mt-1">โปรดเคลียร์โต๊ะอาหารก่อนจัดคิว</p>
            </div>
        `;
    } else {
        container.innerHTML = availableTables.map(t => `
            <label class="cursor-pointer">
                <input type="radio" name="selectedSeatTable" value="${t.id}" class="peer sr-only">
                <div class="p-3 bg-[#100303] border border-red-900 rounded-xl peer-checked:border-emerald-400 peer-checked:bg-emerald-950/60 text-center transition">
                    <p class="font-bold text-white text-sm">${t.name}</p>
                    <span class="text-[10px] text-emerald-400">${t.seats} ที่นั่ง (${t.type})</span>
                </div>
            </label>
        `).join('');
    }

    document.getElementById('seat-table-modal').classList.remove('hidden');
}

function closeSeatTableModal() {
    document.getElementById('seat-table-modal').classList.add('hidden');
    currentSeatingQueueId = null;
}

function confirmSeatQueue() {
    const selectedRadio = document.querySelector('input[name="selectedSeatTable"]:checked');
    if (!selectedRadio) {
        showToast('กรุณาเลือกโต๊ะ', 'โปรดเลือกโต๊ะที่ต้องการให้ลูกค้านั่งทาน', 'warning');
        return;
    }

    const tableId = selectedRadio.value;
    const queues = Store.getQueues();
    const tables = Store.getTables();

    const q = queues.find(item => item.id === currentSeatingQueueId);
    const tbl = tables.find(item => item.id === tableId);

    if (q && tbl && tbl.status === 'available') {
        q.status = 'seated';
        q.tableId = tableId;

        tbl.status = 'occupied';
        tbl.currentQueue = q.queueNumber;

        Store.saveQueues(queues);
        Store.saveTables(tables);

        closeSeatTableModal();
        renderAdminQueues();
        renderTablesManagement();
        renderDashboardMetrics();

        showToast('จัดโต๊ะสำเร็จ!', `จัดคิว ${q.queueNumber} เข้าโต๊ะ ${tbl.name} เรียบร้อยแล้ว`, 'success');
    }
}

function completeQueue(queueId) {
    if (!confirm('ลูกค้ารับประทานเสร็จสิ้น และต้องการเช็คบิลเคลียร์โต๊ะใช่หรือไม่?')) return;

    const queues = Store.getQueues();
    const tables = Store.getTables();

    const q = queues.find(item => item.id === queueId);
    if (q) {
        q.status = 'completed';

        // Free associated table
        if (q.tableId) {
            const tbl = tables.find(t => t.id === q.tableId);
            if (tbl) {
                tbl.status = 'available';
                tbl.currentQueue = null;
            }
        }

        Store.saveQueues(queues);
        Store.saveTables(tables);

        renderAdminQueues();
        renderTablesManagement();
        renderDashboardMetrics();

        showToast('เช็คบิลเสร็จสิ้น', `คิว ${q.queueNumber} เสร็จสิ้นการให้บริการแล้ว`, 'success');
    }
}

// ---------------- WALK-IN QUEUE BOOKING ----------------
function openWalkinModal() {
    document.getElementById('walkin-modal').classList.remove('hidden');
}

function closeWalkinModal() {
    document.getElementById('walkin-modal').classList.add('hidden');
}

function handleWalkinBooking(e) {
    e.preventDefault();
    const name = document.getElementById('walkin-name').value.trim();
    const phone = document.getElementById('walkin-phone').value.trim();
    const partySize = document.getElementById('walkin-party-size').value;
    const notes = document.getElementById('walkin-notes').value.trim();

    let prefix = 'A';
    if (partySize === '3-4') prefix = 'B';
    else if (partySize === '5-8') prefix = 'C';
    else if (partySize === '9+') prefix = 'V';

    const queues = Store.getQueues();
    const currentPrefixQueues = queues.filter(q => q.type === prefix);
    let nextNum = 1;
    if (currentPrefixQueues.length > 0) {
        const highest = currentPrefixQueues.reduce((max, q) => {
            const num = parseInt(q.queueNumber.split('-')[1]) || 0;
            return num > max ? num : max;
        }, 0);
        nextNum = highest + 1;
    }

    const queueNumber = `${prefix}-${String(nextNum).padStart(3, '0')}`;

    const newQueue = {
        id: 'q-' + Date.now(),
        queueNumber: queueNumber,
        type: prefix,
        partySize: partySize,
        customerName: name + ' (Walk-in)',
        customerPhone: phone || '0800000000',
        customerEmail: '',
        branch: 'siam',
        soup: 'mala-classic',
        notes: notes,
        status: 'waiting',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        calledAt: null,
        tableId: null
    };

    queues.push(newQueue);
    Store.saveQueues(queues);

    closeWalkinModal();
    renderAdminQueues();
    renderDashboardMetrics();

    showToast('ออกบัตรคิวสำเร็จ!', `ออกบัตรคิว Walk-in หมายเลข ${queueNumber} สำเร็จ`, 'success');
}

// ==================== 3. TABLE MANAGEMENT ====================
function renderTablesManagement() {
    const grid = document.getElementById('tables-management-grid');
    if (!grid) return;

    const tables = Store.getTables();
    const owner = isOwner();

    // Toggle Add Table Button
    const addTableBtn = document.querySelector('button[onclick="openAddTableModal()"]');
    if (addTableBtn) {
        addTableBtn.style.display = owner ? 'inline-flex' : 'none';
    }

    const statusBadges = {
        available: { label: 'ว่างพร้อมบริการ', color: 'bg-emerald-950 text-emerald-400 border-emerald-700' },
        occupied: { label: 'มีลูกค้านั่งทาน', color: 'bg-red-950 text-red-400 border-red-700' },
        calling: { label: 'กำลังเรียกคิว', color: 'bg-amber-950 text-amber-300 border-amber-700' },
        cleaning: { label: 'กำลังทำความสะอาด', color: 'bg-blue-950 text-blue-300 border-blue-700' }
    };

    grid.innerHTML = tables.map(t => {
        const st = statusBadges[t.status] || statusBadges.available;
        return `
            <div class="p-5 rounded-3xl bg-[#170505] border border-red-900/60 shadow-xl flex flex-col justify-between font-prompt">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-xl font-black text-white font-kanit">${t.name}</span>
                        <span class="px-2.5 py-1 rounded-lg text-xs font-bold border ${st.color}">
                            ${st.label}
                        </span>
                    </div>
                    <div class="text-xs text-gray-400 space-y-1 mb-4">
                        <p>รหัสโต๊ะ: <strong class="text-amber-400 font-mono">${t.id}</strong> | ประเภท: <strong>Type ${t.type}</strong></p>
                        <p>ความจุ: <strong>${t.seats} ที่นั่ง</strong></p>
                        ${t.currentQueue ? `<p class="text-amber-300">คิวที่นั่ง: <strong class="text-white">${t.currentQueue}</strong></p>` : ''}
                    </div>
                </div>

                <div class="pt-3 border-t border-red-900/50 space-y-2">
                    <p class="text-[10px] text-gray-400">เปลี่ยนสถานะโต๊ะ:</p>
                    <div class="grid grid-cols-3 gap-1 text-[11px]">
                        <button onclick="changeTableStatus('${t.id}', 'available')" class="py-1 px-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-center">
                            ว่าง
                        </button>
                        <button onclick="changeTableStatus('${t.id}', 'cleaning')" class="py-1 px-1.5 rounded-lg bg-blue-950 hover:bg-blue-900 text-blue-300 border border-blue-800 text-center">
                            ทำความสะอาด
                        </button>
                        <button onclick="changeTableStatus('${t.id}', 'occupied')" class="py-1 px-1.5 rounded-lg bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 text-center">
                            ไม่ว่าง
                        </button>
                    </div>
                    ${owner ? `
                        <button onclick="editTable('${t.id}')" class="w-full py-1.5 rounded-lg bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800 text-xs">
                            <i class="fa-solid fa-pen-to-square mr-1"></i> แก้ไขข้อมูลโต๊ะ
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }).join('');
}

function changeTableStatus(tableId, newStatus) {
    const tables = Store.getTables();
    const t = tables.find(item => item.id === tableId);
    if (!t) return;

    if (t.currentQueue && newStatus === 'available') {
        showToast('ยังเคลียร์โต๊ะไม่ได้', 'โต๊ะนี้มีคิวใช้งานอยู่ กรุณากดเสร็จสิ้นการทานก่อน', 'warning');
        return;
    }

    t.status = newStatus;
    if (newStatus === 'available') t.currentQueue = null;
    Store.saveTables(tables);
    renderTablesManagement();
    renderDashboardMetrics();
    showToast('อัปเดตโต๊ะแล้ว', `เปลี่ยนสถานะโต๊ะ ${t.name} เป็น "${newStatus}"`, 'info');
}

function openAddTableModal() {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มโต๊ะใหม่ได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    document.getElementById('table-edit-form').reset();
    document.getElementById('table-edit-id').value = '';
    document.querySelector('#table-form-modal h3').innerText = 'เพิ่มโต๊ะอาหารใหม่';
    document.getElementById('table-form-modal').classList.remove('hidden');
}

function editTable(tableId) {
    if (!isOwner()) return;
    const table = Store.getTables().find(item => item.id === tableId);
    if (!table) return;
    document.getElementById('table-edit-id').value = table.id;
    document.getElementById('table-input-id').value = table.id;
    document.getElementById('table-input-name').value = table.name;
    document.getElementById('table-input-type').value = table.type;
    document.getElementById('table-input-seats').value = table.seats;
    document.querySelector('#table-form-modal h3').innerText = 'แก้ไขข้อมูลโต๊ะ';
    document.getElementById('table-form-modal').classList.remove('hidden');
}

function closeAddTableModal() {
    document.getElementById('table-form-modal').classList.add('hidden');
}

function handleSaveTable(e) {
    e.preventDefault();
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มหรือแก้ไขโต๊ะอาหารได้', 'warning');
        return;
    }
    const id = document.getElementById('table-input-id').value.trim().toUpperCase();
    const editId = document.getElementById('table-edit-id').value;
    const name = document.getElementById('table-input-name').value.trim();
    const type = document.getElementById('table-input-type').value;
    const seats = parseInt(document.getElementById('table-input-seats').value) || 2;

    const tables = Store.getTables();
    if (tables.find(t => t.id === id && t.id !== editId)) {
        showToast('รหัสโต๊ะซ้ำ', 'มีรหัสโต๊ะนี้ในระบบแล้ว กรุณาใช้รหัสอื่น', 'warning');
        return;
    }

    if (editId) {
        const table = tables.find(item => item.id === editId);
        if (table) Object.assign(table, { id, name, type, seats });
    } else {
        tables.push({ id, name, type, seats, status: 'available', currentQueue: null });
    }

    Store.saveTables(tables);
    closeAddTableModal();
    renderTablesManagement();
    renderDashboardMetrics();
    showToast(editId ? 'แก้ไขโต๊ะสำเร็จ' : 'เพิ่มโต๊ะสำเร็จ', `${name} ได้รับการบันทึกเรียบร้อยแล้ว`, 'success');
}

// ==================== 4. PROMOTION MANAGEMENT (เจ้าของร้าน) ====================
function renderAdminPromotions() {
    const grid = document.getElementById('admin-promos-grid');
    if (!grid) return;

    const promos = Store.getPromotions();
    const owner = isOwner();

    const addPromoBtn = document.querySelector('button[onclick="openAddPromoModal()"]');
    if (addPromoBtn) {
        addPromoBtn.style.display = owner ? 'inline-flex' : 'none';
    }

    let alertBanner = '';
    if (!owner) {
        alertBanner = `
            <div class="col-span-full p-4 rounded-2xl bg-[#200707] border border-amber-500/40 flex items-center gap-3 font-prompt text-xs text-amber-300">
                <i class="fa-solid fa-lock text-amber-400 text-lg shrink-0"></i>
                <div>
                    <span class="font-bold">โหมดพนักงาน (จำกัดสิทธิ์ - อ่านอย่างเดียว):</span>
                    <span class="text-gray-300"> สิทธิ์พนักงานไม่สามารถเพิ่ม ลบ หรือแก้ไขโปรโมชั่นได้ (เฉพาะเจ้าของร้านเท่านั้น)</span>
                </div>
            </div>
        `;
    }

    grid.innerHTML = alertBanner + promos.map(p => `
        <div class="p-5 rounded-3xl bg-[#170505] border border-red-900/60 shadow-xl flex flex-col justify-between font-prompt">
            <div>
                <div class="h-36 rounded-2xl overflow-hidden bg-black mb-3 relative">
                    <img src="${p.image}" class="w-full h-full object-cover opacity-85">
                    <span class="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                        ${p.category}
                    </span>
                    <span class="absolute bottom-2 right-2 bg-amber-500 text-black text-xs font-black px-2 py-0.5 rounded">
                        ${p.discount}
                    </span>
                </div>
                <h4 class="font-bold text-white text-base font-kanit line-clamp-1">${p.title}</h4>
                <p class="text-xs text-amber-400 mt-0.5 font-mono">โค้ด: ${p.code}</p>
                <p class="text-xs text-gray-400 mt-2 line-clamp-2">${p.desc}</p>
            </div>

            <div class="pt-4 mt-4 border-t border-red-900/50 flex items-center justify-between">
                <span class="text-[10px] text-gray-500">${p.period}</span>
                ${owner ? `
                    <div class="flex gap-2">
                        <button onclick="editPromo('${p.id}')" class="p-2 bg-amber-500/20 text-amber-300 hover:bg-amber-500 hover:text-black rounded-lg text-xs transition" title="แก้ไข">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <button onclick="deletePromo('${p.id}')" class="p-2 bg-red-950 text-red-400 hover:bg-red-800 hover:text-white rounded-lg text-xs transition" title="ลบ">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                ` : `
                    <span class="text-[11px] text-gray-400 bg-[#110303] px-2.5 py-1 rounded-lg border border-red-950 flex items-center gap-1">
                        <i class="fa-solid fa-lock text-[10px] text-amber-500"></i> เฉพาะเจ้าของร้าน
                    </span>
                `}
            </div>
        </div>
    `).join('');
}

function openAddPromoModal() {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มโปรโมชั่นได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    document.getElementById('promo-edit-form').reset();
    document.getElementById('promo-edit-id').value = '';
    document.getElementById('promo-modal-title').innerText = 'เพิ่มโปรโมชั่นใหม่';
    document.getElementById('promo-form-modal').classList.remove('hidden');
}

function closeAddPromoModal() {
    document.getElementById('promo-form-modal').classList.add('hidden');
}

function editPromo(promoId) {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถแก้ไขโปรโมชั่นได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    const promo = Store.getPromotions().find(p => p.id === promoId);
    if (!promo) return;

    document.getElementById('promo-edit-id').value = promo.id;
    document.getElementById('promo-input-title').value = promo.title;
    document.getElementById('promo-input-category').value = promo.category;
    document.getElementById('promo-input-discount').value = promo.discount;
    document.getElementById('promo-input-code').value = promo.code;
    document.getElementById('promo-input-period').value = promo.period;
    document.getElementById('promo-input-image').value = promo.image;
    document.getElementById('promo-input-desc').value = promo.desc;

    document.getElementById('promo-modal-title').innerText = 'แก้ไขโปรโมชั่น';
    document.getElementById('promo-form-modal').classList.remove('hidden');
}

function handleSavePromotion(e) {
    e.preventDefault();
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถบันทึกหรือแก้ไขโปรโมชั่นได้', 'warning');
        return;
    }
    const editId = document.getElementById('promo-edit-id').value;
    const title = document.getElementById('promo-input-title').value.trim();
    const category = document.getElementById('promo-input-category').value;
    const discount = document.getElementById('promo-input-discount').value.trim();
    const code = document.getElementById('promo-input-code').value.trim().toUpperCase() || 'PROMO2026';
    const period = document.getElementById('promo-input-period').value.trim() || 'ตลอดปี 2026';
    const image = document.getElementById('promo-input-image').value.trim() || 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop';
    const desc = document.getElementById('promo-input-desc').value.trim();

    const promos = Store.getPromotions();

    if (editId) {
        const idx = promos.findIndex(p => p.id === editId);
        if (idx !== -1) {
            promos[idx] = { ...promos[idx], title, category, discount, code, period, image, desc };
        }
    } else {
        promos.push({
            id: 'promo-' + Date.now(),
            title,
            category,
            tag: 'NEW DEAL',
            discount,
            period,
            desc,
            image,
            code,
            featured: true
        });
    }

    Store.savePromotions(promos);
    closeAddPromoModal();
    renderAdminPromotions();
    showToast('บันทึกสำเร็จ', 'ข้อมูลโปรโมชั่นได้รับการอัปเดตเรียบร้อยแล้��', 'success');
}

function deletePromo(promoId) {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถลบโปรโมชั่นได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    if (!confirm('ต้องการลบโปรโมชั่นนี้ใช่หรือไม่?')) return;
    let promos = Store.getPromotions();
    promos = promos.filter(p => p.id !== promoId);
    Store.savePromotions(promos);
    renderAdminPromotions();
    showToast('ลบสำเร็จ', 'ลบโปรโมชั่นเรียบร้อยแล้ว', 'info');
}

// ==================== 5. MENU & SOUPS MANAGEMENT ====================
function renderAdminMenus() {
    const tbody = document.getElementById('admin-menu-tbody');
    if (!tbody) return;

    const menus = Store.getMenus();
    const owner = isOwner();

    const addMenuBtn = document.querySelector('button[onclick="openAddMenuModal()"]');
    if (addMenuBtn) {
        addMenuBtn.style.display = owner ? 'inline-flex' : 'none';
    }

    tbody.innerHTML = menus.map(m => `
        <tr class="hover:bg-red-950/40 transition">
            <td class="py-3 px-4 font-bold text-white">${m.name}</td>
            <td class="py-3 px-4 text-gray-400 capitalize">${m.category}</td>
            <td class="py-3 px-4 text-amber-400 font-bold">${m.price}.-</td>
            <td class="py-3 px-4 text-gray-300">${m.stock}</td>
            <td class="py-3 px-4">
                ${owner ? `
                    <button onclick="toggleMenuStatus('${m.id}')" class="px-2.5 py-1 rounded-lg text-xs font-bold transition ${m.status === 'available' ? 'bg-emerald-950 text-emerald-400 border border-emerald-700 hover:bg-emerald-900' : 'bg-red-950 text-red-400 border border-red-700 hover:bg-red-900'}">
                        ${m.status === 'available' ? 'พร้อมเสิร์ฟ' : 'หมดชั่วคราว'}
                    </button>
                ` : `
                    <span class="px-2.5 py-1 rounded-lg text-xs font-bold inline-block ${m.status === 'available' ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800' : 'bg-red-950/70 text-red-400 border border-red-800'}">
                        ${m.status === 'available' ? 'พร้อมเสิร์ฟ' : 'หมดชั่วคราว'}
                    </span>
                `}
            </td>
            <td class="py-3 px-4 text-right">
                ${owner ? `
                    <button onclick="editMenuItem('${m.id}')" class="p-1.5 text-amber-300 hover:text-amber-200 transition" title="แก้ไขเมนู">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button onclick="deleteMenuItem('${m.id}')" class="p-1.5 text-gray-400 hover:text-red-400 transition" title="ลบเมนู">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                ` : `
                    <span class="text-gray-500 text-[11px] font-prompt"><i class="fa-solid fa-lock text-[10px] text-amber-500 mr-1"></i>จำกัดสิทธิ์</span>
                `}
            </td>
        </tr>
    `).join('');
}

function toggleMenuStatus(menuId) {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถแก้ไขข้อมูลสถานะเมนูได้', 'warning');
        return;
    }
    const menus = Store.getMenus();
    const m = menus.find(item => item.id === menuId);
    if (m) {
        m.status = m.status === 'available' ? 'out_of_stock' : 'available';
        Store.saveMenus(menus);
        renderAdminMenus();
        showToast('อัปเดตสถานะเมนู', `${m.name} : ${m.status === 'available' ? 'พร้อมเสิร์ฟ' : 'หมดชั่วคราว'}`, 'info');
    }
}

function openAddMenuModal() {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มเมนูใหม่ได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    document.getElementById('menu-edit-form').reset();
    document.getElementById('menu-edit-id').value = '';
    document.getElementById('menu-modal-title').innerText = 'เพิ่มเมนูอาหาร / น้ำซุป';
    document.getElementById('menu-form-modal').classList.remove('hidden');
}

function editMenuItem(menuId) {
    if (!isOwner()) return;
    const menu = Store.getMenus().find(item => item.id === menuId);
    if (!menu) return;
    document.getElementById('menu-edit-id').value = menu.id;
    document.getElementById('menu-input-name').value = menu.name;
    document.getElementById('menu-input-category').value = menu.category;
    document.getElementById('menu-input-price').value = menu.price;
    document.getElementById('menu-input-stock').value = menu.stock;
    document.getElementById('menu-input-status').value = menu.status;
    document.getElementById('menu-modal-title').innerText = 'แก้ไขเมนูอาหาร / น้ำซุป';
    document.getElementById('menu-form-modal').classList.remove('hidden');
}

function closeAddMenuModal() {
    document.getElementById('menu-form-modal').classList.add('hidden');
}

function handleSaveMenu(e) {
    e.preventDefault();
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มหรือแก้ไขข้อมูลเมนูได้', 'warning');
        return;
    }
    const name = document.getElementById('menu-input-name').value.trim();
    const editId = document.getElementById('menu-edit-id').value;
    const category = document.getElementById('menu-input-category').value;
    const price = parseInt(document.getElementById('menu-input-price').value) || 0;
    const stock = parseInt(document.getElementById('menu-input-stock').value) || 50;
    const status = document.getElementById('menu-input-status').value;

    const menus = Store.getMenus();
    if (editId) {
        const menu = menus.find(item => item.id === editId);
        if (menu) Object.assign(menu, { name, category, price, stock, status });
    } else {
        menus.push({ id: 'm-' + Date.now(), name, category, price, stock, status });
    }

    Store.saveMenus(menus);
    closeAddMenuModal();
    renderAdminMenus();
    showToast(editId ? 'แก้ไขเมนูสำเร็จ' : 'เพิ่มเมนูสำเร็จ', `${name} ได้รับการบันทึกเรียบร้อยแล้ว`, 'success');
}

function deleteMenuItem(menuId) {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถลบรายการอาหารได้', 'warning');
        return;
    }
    if (!confirm('ต้องการลบเมนูนี้ใช่หรือไม่?')) return;
    let menus = Store.getMenus();
    menus = menus.filter(m => m.id !== menuId);
    Store.saveMenus(menus);
    renderAdminMenus();
    showToast('ลบสำเร็จ', 'ลบรายการอาหารเรียบร้อยแล้ว', 'info');
}

// ==================== 6. USERS & STAFF MANAGEMENT ====================
function renderAdminUsers() {
    const tbody = document.getElementById('admin-users-tbody');
    if (!tbody) return;

    const users = Store.getUsers();
    const owner = isOwner();

    const addUserBtn = document.querySelector('button[onclick="openAddUserModal()"]');
    if (addUserBtn) {
        addUserBtn.style.display = owner ? 'inline-flex' : 'none';
    }

    const roleBadges = {
        owner: '<span class="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold">👑 เจ้าของร้าน</span>',
        staff: '<span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">👨‍🍳 พนักงาน</span>',
        customer: '<span class="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold">👤 สมาชิก VIP</span>'
    };

    tbody.innerHTML = users.map(u => `
        <tr class="hover:bg-red-950/40 transition">
            <td class="py-3 px-4 font-bold text-white">${u.name}</td>
            <td class="py-3 px-4 text-amber-300 font-mono">${u.email}</td>
            <td class="py-3 px-4 text-gray-300">${u.phone || '-'}</td>
            <td class="py-3 px-4">${roleBadges[u.role] || u.role}</td>
            <td class="py-3 px-4 text-right">
                ${owner ? `
                    <button onclick="editUserRecord('${u.id}')" class="p-1.5 text-amber-300 hover:text-amber-200 transition" title="แก้ไขผู้ใช้">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button onclick="deleteUserRecord('${u.id}')" class="p-1.5 text-gray-400 hover:text-red-400 transition" title="ลบผู้ใช้">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                ` : `
                    <span class="text-gray-500 text-[11px] font-prompt"><i class="fa-solid fa-lock text-[10px] text-amber-500 mr-1"></i>จำกัดสิทธิ์</span>
                `}
            </td>
        </tr>
    `).join('');
}

function openAddUserModal() {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มผู้ใช้งานใหม่ได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    document.getElementById('user-edit-form').reset();
    document.getElementById('user-edit-id').value = '';
    document.getElementById('user-form-modal').classList.remove('hidden');
}

function editUserRecord(userId) {
    if (!isOwner()) return;
    const user = Store.getUsers().find(item => item.id === userId);
    if (!user) return;
    document.getElementById('user-edit-id').value = user.id;
    document.getElementById('user-input-name').value = user.name;
    document.getElementById('user-input-email').value = user.email;
    document.getElementById('user-input-phone').value = user.phone || '';
    document.getElementById('user-input-role').value = user.role;
    document.getElementById('user-input-password').value = user.password || '';
    document.querySelector('#user-form-modal h3').innerText = 'แก้ไขข้อมูลผู้ใช้ / สิทธิ์';
    document.getElementById('user-form-modal').classList.remove('hidden');
}

function closeAddUserModal() {
    document.getElementById('user-form-modal').classList.add('hidden');
}

function handleSaveUser(e) {
    e.preventDefault();
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถเพิ่มหรือแก้ไขข้อมูลผู้ใช้งานได้', 'warning');
        return;
    }
    const name = document.getElementById('user-input-name').value.trim();
    const editId = document.getElementById('user-edit-id').value;
    const email = document.getElementById('user-input-email').value.trim().toLowerCase();
    const phone = document.getElementById('user-input-phone').value.trim();
    const role = document.getElementById('user-input-role').value;
    const password = document.getElementById('user-input-password').value;

    const users = Store.getUsers();
    if (users.find(u => u.email.toLowerCase() === email && u.id !== editId)) {
        showToast('อีเมลซ้ำ', 'อีเมลนี้ถูกใช้งานแล้วในระบบ', 'warning');
        return;
    }

    if (editId) {
        const user = users.find(item => item.id === editId);
        if (user) Object.assign(user, { name, email, phone, password, role });
    } else {
        users.push({ id: 'u-' + Date.now(), name, email, phone, password, role, created_at: new Date().toISOString().substring(0, 10) });
    }

    Store.saveUsers(users);
    closeAddUserModal();
    renderAdminUsers();
    showToast(editId ? 'แก้ไขผู้ใช้สำเร็จ' : 'เพิ่มผู้ใช้สำเร็จ', `${name} (${role}) ได้รับการบันทึกเรียบร้อยแล้ว`, 'success');
}

function deleteUserRecord(userId) {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถลบข้อมูลผู้ใช้งานได้', 'warning');
        return;
    }
    if (!confirm('ต้องการลบข้อมูลผู้ใช้งานนี้ใช่หรือไม่?')) return;
    let users = Store.getUsers();
    users = users.filter(u => u.id !== userId);
    Store.saveUsers(users);
    renderAdminUsers();
    showToast('ลบสำเร็จ', 'ลบผู้ใช้เรียบร้อยแล้ว', 'info');
}

// ==================== 7. STORE SETTINGS ====================
function renderStoreSettings() {
    const cfg = Store.getConfig();
    if (!cfg) return;

    const owner = isOwner();

    if (document.getElementById('setting-store-name')) {
        document.getElementById('setting-store-name').value = cfg.storeName || 'DRAGON MALA HOTPOT';
        document.getElementById('setting-store-name').disabled = !owner;
    }
    if (document.getElementById('setting-branch-name')) {
        document.getElementById('setting-branch-name').value = cfg.branchName || cfg.storeName || 'DRAGON MALA';
        document.getElementById('setting-branch-name').disabled = !owner;
    }
    if (document.getElementById('setting-phone')) {
        document.getElementById('setting-phone').value = cfg.phone || '';
        document.getElementById('setting-phone').disabled = !owner;
    }
    if (document.getElementById('setting-open-hours')) {
        document.getElementById('setting-open-hours').value = cfg.openHours || '';
        document.getElementById('setting-open-hours').disabled = !owner;
    }
    if (document.getElementById('setting-queue-open')) {
        document.getElementById('setting-queue-open').checked = cfg.isQueueOpen !== false;
        document.getElementById('setting-queue-open').disabled = !owner;
    }
    if (document.getElementById('setting-avg-wait')) {
        document.getElementById('setting-avg-wait').value = cfg.avgWaitPerQueueMinutes || 6;
        document.getElementById('setting-avg-wait').disabled = !owner;
    }
    if (document.getElementById('setting-announcement')) {
        document.getElementById('setting-announcement').value = cfg.announcement || '';
        document.getElementById('setting-announcement').disabled = !owner;
    }

    const submitBtn = document.querySelector('#store-settings-form button[type="submit"]');
    const resetBtn = document.querySelector('button[onclick="resetAllDemoData()"]');
    if (submitBtn) {
        submitBtn.disabled = !owner;
        if (!owner) {
            submitBtn.classList.add('opacity-40', 'cursor-not-allowed');
            submitBtn.title = 'เฉพาะเจ้าของร้านเท่านั้น';
        } else {
            submitBtn.classList.remove('opacity-40', 'cursor-not-allowed');
            submitBtn.title = '';
        }
    }
    if (resetBtn) {
        resetBtn.disabled = !owner;
        if (!owner) {
            resetBtn.classList.add('opacity-40', 'cursor-not-allowed');
            resetBtn.title = 'เฉพาะเจ้าของร้านเท่านั้น';
        } else {
            resetBtn.classList.remove('opacity-40', 'cursor-not-allowed');
            resetBtn.title = '';
        }
    }
}

function saveStoreSettings(e) {
    e.preventDefault();
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'เฉพาะเจ้าของร้านเท่านั้นที่แก้ไขการตั้งค่าร้านค้าได้', 'warning');
        return;
    }
    const cfg = {
        ...Store.getConfig(),
        storeName: document.getElementById('setting-store-name').value.trim(),
        branchName: document.getElementById('setting-branch-name').value.trim(),
        phone: document.getElementById('setting-phone').value.trim(),
        isQueueOpen: document.getElementById('setting-queue-open').checked,
        avgWaitPerQueueMinutes: parseInt(document.getElementById('setting-avg-wait').value) || 6,
        announcement: document.getElementById('setting-announcement').value.trim(),
        openHours: document.getElementById('setting-open-hours').value.trim()
    };

    Store.saveConfig(cfg);
    showToast('บันทึกการตั้งค่าสำเร็จ', 'ระบบร้านค้าได้รับการอัปเดตเรียบร้อยแล้ว', 'success');
}

function resetAllDemoData() {
    if (!isOwner()) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'สิทธิ์พนักงานไม่สามารถรีเซ็ตข้อมูลระบบได้ (เฉพาะเจ้าของร้านเท่านั้น)', 'warning');
        return;
    }
    if (!confirm('คำเตือน: คุณต้องการรีเซ็ตข้อมูลทั้งหมดกลับเป็นค่าเริ่มต้นตัวอย่างใช่หรือไม่?')) return;
    localStorage.clear();
    Store.init();
    renderAllAdminSections();
    showToast('รีเซ็ตข้อมูลแล้ว', 'ระบบได้รับการคืนค่าเริ่มต้นเรียบร้อยแล้ว', 'info');
}

// ==================== 8. FORGOT PASSWORD & RESET LINK FLOW ====================
let adminResetTargetEmail = '';

function openForgotPasswordModal() {
    const modal = document.getElementById('forgot-password-modal');
    if (modal) {
        modal.classList.remove('hidden');
        document.getElementById('forgot-step-request').classList.remove('hidden');
        document.getElementById('forgot-step-email-sent').classList.add('hidden');
        document.getElementById('forgot-step-reset-form').classList.add('hidden');
        
        const currentUser = Store.getCurrentUser();
        if (currentUser && document.getElementById('forgot-email')) {
            document.getElementById('forgot-email').value = currentUser.email;
        }
    }
}

function closeForgotPasswordModal() {
    const modal = document.getElementById('forgot-password-modal');
    if (modal) modal.classList.add('hidden');
}

function handleRequestResetLink(e) {
    e.preventDefault();
    const email = document.getElementById('forgot-email').value.trim().toLowerCase();
    const users = Store.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email);

    if (!user) {
        showToast('ไม่พบอีเมล', `ไม่พบอีเมล "${email}" ในระบบ กรุณาตรวจสอบอีกครั้ง`, 'error');
        return;
    }

    adminResetTargetEmail = user.email;

    document.getElementById('sent-email-destination').innerText = user.email;
    document.getElementById('forgot-step-request').classList.add('hidden');
    document.getElementById('forgot-step-email-sent').classList.remove('hidden');
    document.getElementById('forgot-step-reset-form').classList.add('hidden');

    showToast('ส่งลิงก์สำเร็จ!', `ระบบได้ส่งลิงก์เปลี่ยนรหัสผ่านไปยัง ${user.email} แล้ว`, 'success');
}

function proceedToNewPasswordForm() {
    document.getElementById('reset-target-email').value = adminResetTargetEmail;
    document.getElementById('reset-target-email-label').innerText = adminResetTargetEmail;
    document.getElementById('reset-new-password').value = '';
    document.getElementById('reset-confirm-password').value = '';

    document.getElementById('forgot-step-request').classList.add('hidden');
    document.getElementById('forgot-step-email-sent').classList.add('hidden');
    document.getElementById('forgot-step-reset-form').classList.remove('hidden');
}

function handleSetNewPassword(e) {
    e.preventDefault();
    const email = document.getElementById('reset-target-email').value.trim().toLowerCase();
    const newPass = document.getElementById('reset-new-password').value;
    const confirmPass = document.getElementById('reset-confirm-password').value;

    if (newPass.length < 6) {
        showToast('ข้อผิดพลาด', 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร', 'warning');
        return;
    }

    if (newPass !== confirmPass) {
        showToast('รหัสผ่านไม่ตรงกัน', 'รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน', 'error');
        return;
    }

    const users = Store.getUsers();
    const uIdx = users.findIndex(u => u.email.toLowerCase() === email);

    if (uIdx === -1) {
        showToast('ผิดพลาด', 'ไม่พบข้อมูลผู้ใช้ในระบบ', 'error');
        return;
    }

    users[uIdx].password = newPass;
    Store.saveUsers(users);

    const current = Store.getCurrentUser();
    if (current && current.email.toLowerCase() === email) {
        current.password = newPass;
        Store.setCurrentUser(current);
    }

    closeForgotPasswordModal();
    renderAdminUsers();
    showToast('เปลี่ยนรหัสผ่านสำเร็จ!', `รหัสผ่านของ ${email} ได้รับการอัปเดตเรียบร้อยแล้ว`, 'success');
}
