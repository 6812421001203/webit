/**
 * DRAGON MALA - Front-end Application Controller
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initial Render
    renderStoreIdentity();
    renderQueueBookingState();
    renderPromotions('all');
    renderSoups();
    renderIngredients();
    updateLiveBoardSummary();
    checkCurrentUserStatus();

    document.addEventListener('click', (event) => {
        const profile = document.getElementById('nav-user-profile');
        const menu = document.getElementById('user-profile-menu');
        if (!profile || !menu || profile.contains(event.target)) return;
        menu.classList.add('hidden');
        const toggle = profile.querySelector('button[aria-controls="user-profile-menu"]');
        if (toggle) toggle.setAttribute('aria-expanded', 'false');
    });
    
    // Listen for Real-time Storage Events across browser tabs/windows
    window.addEventListener('storage', (e) => {
        if (!e.key || e.key === STORAGE_KEYS.QUEUES || e.key === STORAGE_KEYS.TABLES || e.key === STORAGE_KEYS.STORE_CONFIG) {
            renderStoreIdentity();
            renderQueueBookingState();
            updateLiveBoardSummary();
            renderOwnerQueues();
            renderOwnerTables();
        }
    });

    // Auto refresh live board every 5 seconds
    setInterval(updateLiveBoardSummary, 5000);

    // Check URL parameters for required auth
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('auth') === 'login') {
        openAuthModal('login');
        if (urlParams.get('redirect') === 'admin') {
            showToast('ต้องเข้าสู่ระบบก่อน', 'กรุณากรอกอีเมลและรหัสผ่านพนักงานหรือเจ้าของร้านเพื่อเข้าสู่ระบบหลังบ้าน', 'warning');
        }
    }
});

function toggleUserMenu(event) {
    event.stopPropagation();
    const menu = document.getElementById('user-profile-menu');
    const toggle = event.currentTarget;
    if (!menu) return;

    const isHidden = menu.classList.toggle('hidden');
    toggle.setAttribute('aria-expanded', String(!isHidden));
}

function renderStoreIdentity() {
    const config = Store.getConfig();
    if (!config) return;

    const storeName = config.storeName || 'DRAGON MALA';
    const branchName = config.branchName || storeName;
    const openHours = config.openHours || '11:00 - 02:00 น.';
    const phone = config.phone || '02-123-4567';

    document.querySelectorAll('.store-name-text').forEach(element => {
        element.textContent = storeName;
    });

    const topStore = document.getElementById('top-announcement-store');
    if (topStore) topStore.textContent = `📍 ${branchName}  | ⏰ เปิดทุกวัน ${openHours}`;

    const topPhone = document.getElementById('top-announcement-phone');
    if (topPhone) {
        topPhone.href = `tel:${phone.replace(/[^\d+]/g, '')}`;
        topPhone.innerHTML = `<i class="fa-solid fa-phone mr-1"></i> ${phone}`;
    }

    const announcement = document.getElementById('top-announcement-text');
    if (announcement) announcement.textContent = config.announcement || '';
}

function renderQueueBookingState() {
    const config = Store.getConfig();
    const form = document.getElementById('booking-form');
    if (!form || !config) return;

    const isOpen = config.isQueueOpen !== false;
    const badge = document.getElementById('booking-queue-status-badge');
    const closedNotice = document.getElementById('booking-closed-notice');
    const submitButton = form.querySelector('button[type="submit"]');

    if (badge) {
        badge.className = isOpen
            ? 'text-xs font-semibold px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1.5'
            : 'text-xs font-semibold px-2.5 py-1 rounded-lg bg-red-950 text-red-300 border border-red-800 flex items-center gap-1.5';
        badge.innerHTML = isOpen
            ? '<span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span> เปิดรับคิว'
            : '<span class="w-2 h-2 rounded-full bg-red-500"></span> ปิดรับคิว';
    }

    if (closedNotice) {
        closedNotice.className = isOpen
            ? 'hidden'
            : 'mb-4 p-3 rounded-xl bg-red-950/80 border border-red-700 text-red-200 text-sm font-prompt';
        closedNotice.innerHTML = isOpen
            ? ''
            : '<i class="fa-solid fa-circle-exclamation mr-1"></i> ขณะนี้ร้านปิดรับจองคิวออนไลน์ชั่วคราว กรุณาติดต่อร้านโดยตรง';
    }

    form.querySelectorAll('input, select, button').forEach(control => {
        control.disabled = !isOpen;
    });
    if (submitButton) {
        submitButton.classList.toggle('opacity-50', !isOpen);
        submitButton.classList.toggle('cursor-not-allowed', !isOpen);
    }
}

// Toast notification system
function showToast(title, message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const colors = {
        success: 'bg-emerald-900/90 border-emerald-500 text-emerald-200',
        error: 'bg-red-950/90 border-red-500 text-red-200',
        warning: 'bg-amber-950/90 border-amber-500 text-amber-200',
        info: 'bg-red-950/90 border-amber-500/50 text-amber-300'
    };
    const icons = {
        success: 'fa-circle-check text-emerald-400',
        error: 'fa-circle-xmark text-red-400',
        warning: 'fa-triangle-exclamation text-amber-400',
        info: 'fa-bell text-amber-400'
    };

    toast.className = `toast-item pointer-events-auto p-4 rounded-2xl border shadow-2xl backdrop-blur-md max-w-sm flex items-start gap-3 ${colors[type] || colors.info}`;
    toast.innerHTML = `
        <i class="fa-solid ${icons[type] || icons.info} text-lg mt-0.5"></i>
        <div class="flex-grow font-prompt">
            <h4 class="font-bold text-sm text-white">${title}</h4>
            <p class="text-xs mt-0.5 opacity-90">${escapeHtml(message)}</p>
        </div>
        <button onclick="this.parentElement.remove()" class="text-gray-400 hover:text-white transition">
            <i class="fa-solid fa-xmark text-xs"></i>
        </button>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}

// ---------------- PROMOTIONS RENDERING ----------------
function renderPromotions(category = 'all') {
    const container = document.getElementById('promotions-grid');
    if (!container) return;

    const promos = Store.getPromotions();
    const filtered = category === 'all' ? promos : promos.filter(p => p.category === category);

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="col-span-full text-center py-12 text-gray-500 font-prompt">
                <i class="fa-solid fa-tag text-3xl mb-2 text-red-800"></i>
                <p>ไม่พบโปรโมชั่นในหมวดหมู่นี้</p>
            </div>
        `;
        return;
    }

    container.innerHTML = filtered.map(promo => `
        <div class="rounded-3xl bg-[#1c0606] border border-red-900/60 hover:border-amber-500/50 transition-all duration-300 overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-red-950/80 group flex flex-col justify-between">
            <div class="relative h-48 sm:h-52 overflow-hidden bg-black">
                <img src="${promo.image}" alt="${promo.title}" 
                     class="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-85">
                <div class="absolute inset-0 bg-gradient-to-t from-[#1c0606] via-transparent to-transparent"></div>
                
                <span class="absolute top-3 left-3 bg-red-600/90 backdrop-blur-md text-amber-200 font-black text-[10px] px-2.5 py-1 rounded-lg border border-amber-400/40 tracking-wider">
                    ${promo.tag}
                </span>

                <span class="absolute bottom-3 right-3 bg-amber-500 text-slate-950 font-black text-xs px-2.5 py-1 rounded-xl shadow">
                    ${promo.discount}
                </span>
            </div>

            <div class="p-5 flex-grow flex flex-col justify-between font-prompt">
                <div>
                    <div class="flex items-center gap-1.5 text-xs text-amber-400/80 mb-1">
                        <i class="fa-regular fa-clock"></i>
                        <span>${promo.period}</span>
                    </div>
                    <h3 class="text-base font-bold text-white group-hover:text-amber-300 transition line-clamp-1 font-kanit">
                        ${promo.title}
                    </h3>
                    <p class="text-xs text-gray-400 mt-2 line-clamp-2 leading-relaxed">
                        ${promo.desc}
                    </p>
                </div>

                <div class="pt-4 mt-4 border-t border-red-900/50 flex items-center justify-between">
                    <div class="text-[11px] text-gray-400 font-mono">
                        โค้ด: <span class="text-amber-300 font-bold bg-red-950 px-2 py-0.5 rounded border border-red-800">${promo.code}</span>
                    </div>
                    <button onclick="openPromoDetail('${promo.id}')" class="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition">
                        ดูเงื่อนไข <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function filterPromos(category) {
    document.querySelectorAll('.promo-filter-btn').forEach(btn => {
        btn.classList.remove('bg-red-700', 'text-white', 'active');
        btn.classList.add('bg-red-950/60', 'text-gray-300');
    });

    event.currentTarget.classList.add('bg-red-700', 'text-white', 'active');
    event.currentTarget.classList.remove('bg-red-950/60', 'text-gray-300');

    renderPromotions(category);
}

function openPromoDetail(promoId) {
    const promo = Store.getPromotions().find(p => p.id === promoId);
    if (!promo) return;

    const modal = document.getElementById('promo-modal');
    const content = document.getElementById('promo-modal-content');

    content.innerHTML = `
        <div class="rounded-2xl overflow-hidden mb-4 h-48 bg-black relative">
            <img src="${promo.image}" class="w-full h-full object-cover opacity-90">
            <div class="absolute inset-0 bg-gradient-to-t from-[#1c0606] via-transparent to-transparent"></div>
            <span class="absolute bottom-3 left-3 bg-red-600 text-white font-bold text-xs px-3 py-1 rounded-lg">
                ${promo.discount}
            </span>
        </div>
        <h3 class="text-xl font-black text-white font-kanit">${promo.title}</h3>
        <p class="text-xs text-amber-400 mt-1 flex items-center gap-1">
            <i class="fa-solid fa-calendar-days"></i> ระยะเวลาโปรโมชั่น: ${promo.period}
        </p>
        <p class="text-sm text-gray-300 mt-3 leading-relaxed">${promo.desc}</p>
        
        <div class="my-4 p-3 bg-red-950/60 rounded-xl border border-red-900 text-xs text-gray-300 space-y-1">
            <p class="font-bold text-amber-300">📌 เงื่อนไขการใช้โปรโมชั่น:</p>
            <p>• แสดงโค้ด <span class="text-amber-400 font-bold">${promo.code}</span> ต่อพนักงานก่อนสั่งอาหาร</p>
            <p>• ใช้ได้ที่หน้าร้าน DRAGON MALA ไม่สามารถแลกเปลี่ยนเป็นเงินสดได้</p>
            <p>• สงวนสิทธิ์ 1 สิทธิ์ ต่อ 1 โต๊ะ/บิล</p>
        </div>

        <div class="flex gap-2">
            <a href="#queue-section" onclick="closePromoModal()" class="flex-1 py-3 text-center bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold rounded-xl text-sm transition">
                <i class="fa-solid fa-ticket mr-1"></i> จองคิวใช้โปรนี้ทันที
            </a>
            <button onclick="closePromoModal()" class="px-5 py-3 bg-red-950 hover:bg-red-900 text-gray-300 rounded-xl text-sm transition">
                ปิด
            </button>
        </div>
    `;

    modal.classList.remove('hidden');
}

function openPromoDetailModal(type) {
    if (type === 'member-info') {
        const modal = document.getElementById('promo-modal');
        const content = document.getElementById('promo-modal-content');
        content.innerHTML = `
            <div class="text-center py-2 font-prompt">
                <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-red-600 text-slate-950 flex items-center justify-center text-2xl mx-auto mb-3 shadow-lg">
                    <i class="fa-solid fa-crown"></i>
                </div>
                <h3 class="text-2xl font-black text-white font-kanit">สิทธิประโยชน์สมาชิก DRAGON MALA</h3>
                <p class="text-xs text-amber-400 mt-1">สมัครฟรีผ่านอีเมล ไม่เสียค่าธรรมเนียมใดๆ ทั้งสิ้น</p>

                <div class="my-5 text-left space-y-3 text-xs text-gray-300 bg-[#120303] p-4 rounded-2xl border border-red-900/60">
                    <div class="flex items-start gap-2.5">
                        <i class="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                        <span><strong>รับสิทธิ์โปรโมชั่นพิเศษ</strong> และคูปองฟรีน้ำซุปทันที</span>
                    </div>
                    <div class="flex items-start gap-2.5">
                        <i class="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                        <span><strong>ฟรี! ซุปหมาล่านมสด</strong> หรือน้ำซุปใดๆ 1 หม้อ ในเดือนเกิด</span>
                    </div>
                    <div class="flex items-start gap-2.5">
                        <i class="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                        <span><strong>รับสิทธิ์ส่วนลดพิเศษ</strong> โปรโมชั่นบุฟเฟต์และเซ็ตสุดคุ้ม</span>
                    </div>
                    <div class="flex items-start gap-2.5">
                        <i class="fa-solid fa-check text-emerald-400 mt-0.5"></i>
                        <span><strong>สิทธิ์เข้าทานคิวพิเศษ VIP</strong> ในวันเกิดหรือสมาชิกระดับ Gold</span>
                    </div>
                </div>

                <div class="flex gap-2">
                    <button onclick="closePromoModal(); openAuthModal('register')" class="flex-1 py-3 bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold rounded-xl text-sm transition">
                        สมัครสมาชิกทันที
                    </button>
                    <button onclick="closePromoModal()" class="px-5 py-3 bg-red-950 text-gray-300 rounded-xl text-sm">
                        ปิด
                    </button>
                </div>
            </div>
        `;
        modal.classList.remove('hidden');
    }
}

function closePromoModal() {
    const modal = document.getElementById('promo-modal');
    if (modal) modal.classList.add('hidden');
}

// ---------------- SOUPS & INGREDIENTS RENDERING ----------------
function renderSoups() {
    const container = document.getElementById('soups-container');
    if (!container) return;

    container.innerHTML = INITIAL_SOUPS.map(soup => `
        <div class="p-5 rounded-3xl bg-[#170505] border border-red-900/60 hover:border-amber-500/50 transition duration-300 flex flex-col justify-between group">
            <div>
                <div class="flex items-center justify-between mb-3">
                    <div class="w-10 h-10 rounded-xl bg-red-950 border border-red-800 flex items-center justify-center text-lg">
                        <i class="fa-solid ${soup.icon}"></i>
                    </div>
                    <span class="text-[10px] bg-red-950 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                        ${soup.badge}
                    </span>
                </div>
                <h4 class="text-base font-bold text-white font-kanit group-hover:text-amber-300 transition">${soup.name}</h4>
                <p class="text-[11px] text-gray-400 font-prompt">${soup.sub}</p>
                <div class="my-2">
                    <span class="text-xs text-red-400 font-bold font-prompt bg-red-950/60 px-2 py-0.5 rounded border border-red-900">${soup.level}</span>
                </div>
                <p class="text-xs text-gray-300 font-prompt leading-relaxed mt-2 line-clamp-3">${soup.desc}</p>
            </div>
            <div class="pt-4 mt-4 border-t border-red-900/40 flex items-center justify-between">
                <span class="text-sm font-black text-amber-400 font-prompt">${soup.price}.-</span>
                <a href="#queue-section" class="text-xs text-gray-300 hover:text-amber-300 transition flex items-center gap-1 font-prompt">
                    เลือกซุปนี้ <i class="fa-solid fa-chevron-right text-[10px]"></i>
                </a>
            </div>
        </div>
    `).join('');
}

function renderIngredients() {
    const container = document.getElementById('ingredients-container');
    if (!container) return;

    container.innerHTML = INITIAL_INGREDIENTS.map(item => `
        <div class="rounded-2xl bg-[#170505] border border-red-900/50 p-2.5 hover:border-amber-500/40 transition group">
            <div class="h-28 rounded-xl overflow-hidden bg-black mb-2 relative">
                <img src="${item.img}" alt="${item.name}" class="w-full h-full object-cover group-hover:scale-110 transition duration-500">
                <span class="absolute bottom-1 right-1 bg-black/80 text-amber-300 font-black text-[10px] px-1.5 py-0.5 rounded">
                    ${item.price}
                </span>
            </div>
            <p class="text-xs font-bold text-gray-200 truncate font-prompt group-hover:text-amber-300">${item.name}</p>
        </div>
    `).join('');
}

// ---------------- QUEUE BOOKING LOGIC (หน้าบ้าน) ----------------
function handleQueueBooking(e) {
    e.preventDefault();

    const config = Store.getConfig();
    if (config.isQueueOpen === false) {
        renderQueueBookingState();
        showToast('ปิดรับจองคิวออนไลน์', 'ขณะนี้ร้านยังไม่เปิดรับคิวใหม่ กรุณาลองอีกครั้งภายหลัง', 'warning');
        return;
    }

    const currentUser = Store.getCurrentUser();
    if (!currentUser) {
        showToast('เฉพาะสมาชิกเท่านั้น', 'ต้องสมัครสมาชิกหรือเข้าสู่ระบบก่อนจึงจะสามารถจองคิวได้', 'warning');
        openAuthModal('register');
        return;
    }

    const branch = document.getElementById('queue-branch') ? document.getElementById('queue-branch').value : 'siam';
    const partySizeRadio = document.querySelector('input[name="partySize"]:checked');
    const partySize = partySizeRadio ? partySizeRadio.value : '1-2';
    const soup = document.getElementById('queue-soup') ? document.getElementById('queue-soup').value : 'mala-classic';
    const notes = document.getElementById('queue-notes') ? document.getElementById('queue-notes').value.trim() : '';

    // Determine Queue Prefix
    let prefix = 'A';
    if (partySize === '3-4') prefix = 'B';
    else if (partySize === '5-8') prefix = 'C';
    else if (partySize === '9+') prefix = 'V';

    const queues = Store.getQueues();
    
    // Calculate new sequential number
    const currentPrefixQueues = queues.filter(q => q.type === prefix);
    let nextNum = 1;
    if (currentPrefixQueues.length > 0) {
        const highest = currentPrefixQueues.reduce((max, q) => {
            const num = parseInt(q.queueNumber.split('-')[1]) || 0;
            return num > max ? num : max;
        }, 0);
        nextNum = highest + 1;
    }

    const queueNumber = `${prefix}-${String(nextNum).padStart(3, '0')}`;
    const newQueueId = 'q-' + Date.now();

    const newQueue = {
        id: newQueueId,
        queueNumber: queueNumber,
        type: prefix,
        partySize: partySize,
        customerName: currentUser.name || 'สมาชิก',
        customerPhone: currentUser.phone || '-',
        customerEmail: currentUser.email || '',
        branch: branch,
        soup: soup,
        notes: notes,
        status: 'waiting',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        calledAt: null,
        tableId: null
    };

    queues.push(newQueue);
    Store.saveQueues(queues);

    addAutoTableForQueue(newQueue);

    // Calculate queues ahead count
    const waitingBefore = queues.filter(q => q.type === prefix && q.status === 'waiting' && q.id !== newQueueId).length;
    const avgWait = Number(config.avgWaitPerQueueMinutes) || 6;
    const estWaitMinutes = (waitingBefore + 1) * avgWait;

    // Show Confirmation Ticket Modal
    if (document.getElementById('ticket-queue-number')) {
        document.getElementById('ticket-queue-number').innerText = queueNumber;
    }
    if (document.getElementById('ticket-customer-name')) {
        document.getElementById('ticket-customer-name').innerText = currentUser.name || 'สมาชิก';
    }
    if (document.getElementById('ticket-party-size')) {
        document.getElementById('ticket-party-size').innerText = partySize + ' ท่าน';
    }
    if (document.getElementById('ticket-table-type')) {
        const typeLabels = { '1-2': 'โต๊ะเล็ก (Type A)', '3-4': 'โต๊ะกลาง (Type B)', '5-8': 'โต๊ะใหญ่ (Type C)', '9+': 'ห้อง VIP (Type V)' };
        document.getElementById('ticket-table-type').innerText = typeLabels[partySize] || `Type ${prefix}`;
    }
    if (document.getElementById('ticket-ahead-count')) {
        document.getElementById('ticket-ahead-count').innerText = waitingBefore + ' คิว';
    }
    if (document.getElementById('ticket-est-time')) {
        document.getElementById('ticket-est-time').innerText = `~${estWaitMinutes} นาที`;
    }
    
    const branchNames = {
        siam: 'DRAGON MALA สาขาหลัก สยามสแควร์วัน (ชั้น 4)',
        main: 'DRAGON MALA สาขาหลัก สยามสแควร์วัน (ชั้น 4)'
    };
    if (document.getElementById('ticket-branch-name')) {
        document.getElementById('ticket-branch-name').innerText = branchNames[branch] || 'DRAGON MALA สาขาหลัก สยามสแควร์วัน (ชั้น 4)';
    }

    if (document.getElementById('ticket-modal')) {
        document.getElementById('ticket-modal').classList.remove('hidden');
    }

    // Reset Form
    const bookingForm = document.getElementById('booking-form');
    if (bookingForm) {
        bookingForm.reset();
    }

    updateLiveBoardSummary();
    renderOwnerQueues();
    renderOwnerTables();
    showToast('จองคิวสำเร็จ!', `คุณ ${currentUser.name} ได้รับหมายเลขคิว ${queueNumber} (${waitingBefore} คิวก่อนหน้า)`, 'success');
}

function addAutoTableForQueue(queue) {
    const seatsByPartySize = { '1-2': 2, '3-4': 4, '5-8': 8, '9+': 12 };
    const seats = seatsByPartySize[queue.partySize] || 2;
    const tables = Store.getTables();
    const prefix = queue.type;
    const autoTables = tables.filter(table => table.autoCreated && table.type === prefix);
    const nextNumber = autoTables.reduce((highest, table) => {
        const number = parseInt(String(table.id).split('-').pop(), 10) || 0;
        return Math.max(highest, number);
    }, 0) + 1;
    const tableNumber = String(nextNumber).padStart(3, '0');

    tables.push({
        id: `AUTO-${prefix}-${tableNumber}`,
        name: `โต๊ะ ${prefix} อัตโนมัติ ${tableNumber}`,
        type: prefix,
        seats,
        status: 'available',
        currentQueue: null,
        autoCreated: true
    });
    Store.saveTables(tables);
}

function closeTicketModal() {
    document.getElementById('ticket-modal').classList.add('hidden');
}

function printTicket() {
    window.print();
}

// ---------------- LIVE QUEUE BOARD UPDATER ----------------
function updateLiveBoardSummary() {
    const queues = Store.getQueues();
    
    // Type A
    const callingA = queues.find(q => q.type === 'A' && q.status === 'calling');
    const waitingACount = queues.filter(q => q.type === 'A' && q.status === 'waiting').length;
    document.getElementById('board-call-a').innerText = callingA ? `กำลังเรียก: ${callingA.queueNumber}` : 'กำลังเรียก: -';
    document.getElementById('board-wait-a').innerText = waitingACount > 0 ? `${waitingACount} คิว` : 'ว่าง';

    // Type B
    const callingB = queues.find(q => q.type === 'B' && q.status === 'calling');
    const waitingBCount = queues.filter(q => q.type === 'B' && q.status === 'waiting').length;
    document.getElementById('board-call-b').innerText = callingB ? `กำลังเรียก: ${callingB.queueNumber}` : 'กำลังเรียก: -';
    document.getElementById('board-wait-b').innerText = waitingBCount > 0 ? `${waitingBCount} คิว` : 'ว่าง';

    // Type C
    const callingC = queues.find(q => q.type === 'C' && q.status === 'calling');
    const waitingCCount = queues.filter(q => q.type === 'C' && q.status === 'waiting').length;
    document.getElementById('board-call-c').innerText = callingC ? `กำลังเรียก: ${callingC.queueNumber}` : 'กำลังเรียก: -';
    document.getElementById('board-wait-c').innerText = waitingCCount > 0 ? `${waitingCCount} คิว` : 'ว่าง';

    // Type V
    const callingV = queues.find(q => q.type === 'V' && q.status === 'calling');
    const waitingVCount = queues.filter(q => q.type === 'V' && q.status === 'waiting').length;
    document.getElementById('board-call-v').innerText = callingV ? `กำลังเรียก: ${callingV.queueNumber}` : 'กำลังเรียก: -';
    document.getElementById('board-wait-v').innerText = waitingVCount > 0 ? `${waitingVCount} คิว` : 'ว่าง';

    // Hero Section summary
    const totalWaiting = queues.filter(q => q.status === 'waiting').length;
    const anyCalling = queues.filter(q => q.status === 'calling');
    const latestCalling = anyCalling.length > 0 ? anyCalling[anyCalling.length - 1].queueNumber : '-';

    if (document.getElementById('hero-current-calling')) {
        document.getElementById('hero-current-calling').innerText = latestCalling;
    }
    if (document.getElementById('hero-total-waiting')) {
        document.getElementById('hero-total-waiting').innerText = `${totalWaiting} คิว`;
    }
    if (document.getElementById('hero-est-wait')) {
        document.getElementById('hero-est-wait').innerText = totalWaiting > 0 ? `~${Math.max(5, totalWaiting * 5)} นาที` : 'พร้อมบริการ';
    }
}

function refreshQueueBoard() {
    updateLiveBoardSummary();
    showToast('อัปเดตข้อมูลแล้ว', 'กระดานแสดงสถานะคิวเป็นปัจจุบันเรียบร้อยแล้ว', 'info');
}

// ---------------- SEARCH QUEUE STATUS ----------------
function searchMyQueue() {
    const query = document.getElementById('search-queue-input').value.trim().toLowerCase();
    const resultBox = document.getElementById('search-queue-result');
    if (!query) {
        showToast('แจ้งเตือน', 'กรุณาระบุหมายเลขคิว หรือข้อมูลสมาชิก', 'warning');
        return;
    }

    const queues = Store.getQueues();
    const found = queues.filter(q =>
        q.queueNumber.toLowerCase() === query ||
        (q.customerPhone && q.customerPhone !== '-' && q.customerPhone === query) ||
        (q.customerEmail && q.customerEmail.toLowerCase() === query)
    );

    resultBox.classList.remove('hidden');

    if (found.length === 0) {
        resultBox.innerHTML = `
            <div class="p-4 bg-red-950/40 rounded-2xl border border-red-900 text-center font-prompt">
                <i class="fa-solid fa-triangle-exclamation text-amber-400 text-xl mb-1"></i>
                <p class="text-xs text-gray-300">ไม่พบคิวที่ตรงกับ "<strong>${escapeHtml(query)}</strong>"</p>
                <p class="text-[11px] text-gray-500 mt-1">โปรดตรวจสอบหมายเลขคิว หรือข้อมูลสมาชิกอีกครั้ง</p>
            </div>
        `;
        return;
    }

    const statusMap = {
        waiting: { text: 'รอเรียกคิว', color: 'bg-amber-950 text-amber-300 border-amber-700' },
        calling: { text: 'กำลังเรียกคิว! (โปรดแสดงตัว)', color: 'bg-red-600 text-white animate-pulse' },
        seated: { text: 'เข้ารับบริการแล้ว', color: 'bg-emerald-950 text-emerald-300 border-emerald-700' },
        completed: { text: 'เสร็จสิ้นการใช้บริการ', color: 'bg-gray-800 text-gray-400' },
        cancelled: { text: 'ยกเลิกคิวแล้ว', color: 'bg-red-950 text-red-400 border-red-900' }
    };

    const currentUser = Store.getCurrentUser();
    resultBox.innerHTML = found.map(q => {
        const st = statusMap[q.status] || statusMap.waiting;
        const waitingAhead = queues.filter(item => item.type === q.type && item.status === 'waiting' && item.createdAt < q.createdAt).length;
        const canCancel = currentUser && q.customerEmail && q.customerEmail.toLowerCase() === currentUser.email.toLowerCase();

        return `
            <div class="p-4 bg-[#140404] rounded-2xl border border-red-800/80 mb-3 font-prompt">
                <div class="flex items-center justify-between border-b border-red-900/50 pb-2 mb-2">
                    <span class="text-2xl font-black text-amber-400 font-kanit">${escapeHtml(q.queueNumber)}</span>
                    <span class="text-xs font-bold px-2.5 py-1 rounded-lg border ${st.color}">${st.text}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-xs text-gray-300">
                    <div>สมาชิก: <strong class="text-amber-300">${escapeHtml(q.customerName)}</strong></div>
                    <div>ประเภท: <strong class="text-white">Type ${escapeHtml(q.type)} (${escapeHtml(q.partySize)} ท่าน)</strong></div>
                    <div>เวลาที่จอง: <span class="text-gray-400">${escapeHtml(q.createdAt.substring(11, 16))} น.</span></div>
                    <div>คิวก่อนหน้า: <strong class="text-red-400">${q.status === 'waiting' ? `${waitingAhead} คิว` : '-'}</strong></div>
                </div>
                ${q.status === 'waiting' && canCancel ? `
                    <div class="mt-3 pt-2 border-t border-red-900/40 flex justify-between items-center">
                        <span class="text-[11px] text-gray-400">เวลารอประมาณ: ~${(waitingAhead + 1) * 6} นาที</span>
                        <button onclick="cancelQueue('${q.id}')" class="text-xs text-red-400 hover:text-red-300 font-medium">
                            <i class="fa-solid fa-trash-can mr-1"></i> ขอยกเลิกคิว
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');
}

function showMyQueues() {
    const user = Store.getCurrentUser();
    if (!user) {
        openAuthModal('login');
        return;
    }
    document.getElementById('search-queue-input').value = user.phone || user.email;
    searchMyQueue();
    location.hash = '#check-queue';
}

function cancelQueue(queueId) {
    if (!confirm('คุณต้องการยกเลิกการจองคิวนี้ใช่หรือไม่?')) return;

    const currentUser = Store.getCurrentUser();
    if (!currentUser) {
        showToast('กรุณาเข้าสู่ระบบ', 'ต้องเข้าสู่ระบบก่อนจึงจะยกเลิกคิวได้', 'warning');
        return;
    }

    const queues = Store.getQueues();
    const idx = queues.findIndex(q => q.id === queueId);
    const queue = idx !== -1 ? queues[idx] : null;
    if (queue && queue.customerEmail && queue.customerEmail.toLowerCase() === currentUser.email.toLowerCase()) {
        queue.status = 'cancelled';
        Store.saveQueues(queues);
        updateLiveBoardSummary();
        searchMyQueue();
        showToast('ยกเลิกคิวแล้ว', 'คุณได้ยกเลิกคิวเรียบร้อยแล้ว', 'info');
    }
}

// ---------------- AUTHENTICATION & MEMBERSHIP ----------------
function openAuthModal(tab = 'login') {
    const modal = document.getElementById('auth-modal');
    modal.classList.remove('hidden');
    switchAuthTab(tab);
}

function closeAuthModal() {
    document.getElementById('auth-modal').classList.add('hidden');
}

function switchAuthTab(tab) {
    const loginForm = document.getElementById('login-form');
    const regForm = document.getElementById('register-form');
    const tabLoginBtn = document.getElementById('tab-login-btn');
    const tabRegBtn = document.getElementById('tab-register-btn');

    if (tab === 'login') {
        loginForm.classList.remove('hidden');
        regForm.classList.add('hidden');
        tabLoginBtn.className = 'text-lg font-bold text-amber-400 pb-2 border-b-2 border-amber-400 transition flex items-center gap-2';
        tabRegBtn.className = 'text-lg font-bold text-gray-400 pb-2 border-b-2 border-transparent hover:text-gray-200 transition flex items-center gap-2';
    } else {
        loginForm.classList.add('hidden');
        regForm.classList.remove('hidden');
        tabRegBtn.className = 'text-lg font-bold text-amber-400 pb-2 border-b-2 border-amber-400 transition flex items-center gap-2';
        tabLoginBtn.className = 'text-lg font-bold text-gray-400 pb-2 border-b-2 border-transparent hover:text-gray-200 transition flex items-center gap-2';
    }
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim().toLowerCase();
    const password = document.getElementById('login-password').value;

    const users = Store.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email && u.password === password);

    if (!user) {
        showToast('เข้าสู่ระบบไม่สำเร็จ', 'อีเมลหรือรหัสผ่านไม่ถูกต้อง โปรดลองใหม่อีกครั้ง', 'error');
        return;
    }

    Store.setCurrentUser(user);
    checkCurrentUserStatus();
    closeAuthModal();
    showToast('เข้าสู่ระบบสำเร็จ', `ยินดีต้อนรับ ${user.name} (${user.role === 'owner' ? 'เจ้าของร้าน' : user.role === 'staff' ? 'พนักงาน' : 'สมาชิก'})`, 'success');

    // If staff/owner, handle navigation
    if (user.role === 'owner' || user.role === 'staff') {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('redirect') === 'admin') {
            window.location.href = 'admin.html';
            return;
        }
        setTimeout(() => {
            if (confirm('คุณเข้าสู่ระบบในฐานะ ' + (user.role === 'owner' ? 'เจ้าของร้าน' : 'พนักงาน') + ' ต้องการไปที่หน้าจัดการหลังบ้าน (Staff/Owner Dashboard) เลยหรือไม่?')) {
                window.location.href = 'admin.html';
            }
        }, 800);
    }
}

function handleAdminEntrance(e) {
    const user = Store.getCurrentUser();
    if (!user) {
        if (e) e.preventDefault();
        openAuthModal('login');
        showToast('ต้องเข้าสู่ระบบก่อน', 'เมนูหลังบ้านสงวนสิทธิ์เฉพาะพนักงานและเจ้าของร้านเท่านั้น กรุณาเข้าสู่ระบบ', 'warning');
    } else if (user.role !== 'owner' && user.role !== 'staff') {
        if (e) e.preventDefault();
        showToast('ไม่มีสิทธิ์เข้าถึง', 'เมนูหลังบ้านสงวนสิทธิ์เฉพาะพนักงานและเจ้าของร้านเท่านั้น สมาชิกทั่วไปไม่สามารถเข้าถึงได้', 'error');
    }
}

function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim().toLowerCase();
    const phone = document.getElementById('reg-phone').value.trim();
    const password = document.getElementById('reg-password').value;

    const users = Store.getUsers();
    if (users.find(u => u.email.toLowerCase() === email)) {
        showToast('สมัครสมาชิกไม่สำเร็จ', 'อีเมลนี้ถูกใช้งานในระบบแล้ว กรุณาใช้อีเมลอื่นหรือเข้าสู่ระบบ', 'warning');
        return;
    }

    const newUser = {
        id: 'u-' + Date.now(),
        name: name,
        email: email,
        phone: phone,
        password: password,
        role: 'customer',
        created_at: new Date().toISOString().substring(0, 10)
    };

    users.push(newUser);
    Store.saveUsers(users);
    Store.setCurrentUser(newUser);

    checkCurrentUserStatus();
    closeAuthModal();
    showToast('ส��ัครสมาชิกสำเร็จ!', `ยินดีต้อนรับคุณ ${newUser.name} เข้าสู่ Dragon Mala Club เรียบร้อยแล้ว`, 'success');
}

function handleLogout() {
    Store.logoutUser();
    checkCurrentUserStatus();
    showToast('ออกจากระบบแล้ว', 'ขอบคุณที่ใช้บริการ Dragon Mala', 'info');
}

// ---------------- FORGOT PASSWORD & EMAIL RESET LINK FLOW ----------------
let currentResetTargetEmail = '';

function openForgotPasswordModal() {
    closeAuthModal();
    const modal = document.getElementById('forgot-password-modal');
    if (modal) {
        modal.classList.remove('hidden');
        document.getElementById('forgot-step-request').classList.remove('hidden');
        document.getElementById('forgot-step-email-sent').classList.add('hidden');
        document.getElementById('forgot-step-reset-form').classList.add('hidden');
        
        // Auto fill if something was in login email
        const loginEmail = document.getElementById('login-email')?.value;
        if (loginEmail) {
            document.getElementById('forgot-email').value = loginEmail;
        }
    }
}

function closeForgotPasswordModal() {
    const modal = document.getElementById('forgot-password-modal');
    if (modal) modal.classList.add('hidden');
}

function backToLoginFromForgot() {
    closeForgotPasswordModal();
    openAuthModal('login');
}

function handleRequestResetLink(e) {
    e.preventDefault();
    const email = document.getElementById('forgot-email').value.trim().toLowerCase();
    const users = Store.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email);

    if (!user) {
        showToast('ไม่พบอีเมล', `ไม่พบอีเมล "${email}" ในระบบ กรุณาตรวจสอบอีกครั้งหรือสมัครสมาชิกใหม่`, 'error');
        return;
    }

    currentResetTargetEmail = user.email;

    // Show step 2: Simulated Email sent preview
    document.getElementById('sent-email-destination').innerText = user.email;
    document.getElementById('forgot-step-request').classList.add('hidden');
    document.getElementById('forgot-step-email-sent').classList.remove('hidden');
    document.getElementById('forgot-step-reset-form').classList.add('hidden');

    showToast('ส่งลิงก์สำเร็จ!', `ระบบได้ส่งลิงก์เปลี่ยนรหัสผ่านไปยัง ${user.email} แล้ว`, 'success');
}

function proceedToNewPasswordForm() {
    document.getElementById('reset-target-email').value = currentResetTargetEmail;
    document.getElementById('reset-target-email-label').innerText = currentResetTargetEmail;
    document.getElementById('reset-new-password').value = '';
    document.getElementById('reset-confirm-password').value = '';

    document.getElementById('forgot-step-request').classList.add('hidden');
    document.getElementById('forgot-step-email-sent').classList.add('hidden');
    document.getElementById('forgot-step-reset-form').classList.remove('hidden');
}

function handleSetNewPassword(e) {
    e.preventDefault();
    const email = document.getElementById('reset-target-email').value.trim().toLowerCase();
    const newPass = document.getElementById('reset-new-password').value;
    const confirmPass = document.getElementById('reset-confirm-password').value;

    if (newPass.length < 6) {
        showToast('ข้อผิดพลาด', 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร', 'warning');
        return;
    }

    if (newPass !== confirmPass) {
        showToast('รหัสผ่านไม่ตรงกัน', 'รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน', 'error');
        return;
    }

    const users = Store.getUsers();
    const uIdx = users.findIndex(u => u.email.toLowerCase() === email);

    if (uIdx === -1) {
        showToast('ผิดพลาด', 'ไม่พบข้อมูลผู้ใช้ในระบบ', 'error');
        return;
    }

    // Update password
    users[uIdx].password = newPass;
    Store.saveUsers(users);

    // If current logged-in user is this one, update session
    const current = Store.getCurrentUser();
    if (current && current.email.toLowerCase() === email) {
        current.password = newPass;
        Store.setCurrentUser(current);
    }

    closeForgotPasswordModal();
    openAuthModal('login');

    // Auto-fill new credentials
    document.getElementById('login-email').value = email;
    document.getElementById('login-password').value = newPass;

    showToast('เปลี่ยนรหัสผ่านสำเร็จ!', 'คุณสามารถเข้าสู่ระบบด้วยรหัสผ่านใหม่ได้ทันที', 'success');
}

function checkCurrentUserStatus() {
    const user = Store.getCurrentUser();
    const guestBtns = document.getElementById('nav-guest-btns');
    const userProfile = document.getElementById('nav-user-profile');
    const mobileGuest = document.getElementById('mobile-guest-auth');
    const mobileUser = document.getElementById('mobile-user-auth');
    const adminLinkContainer = document.getElementById('nav-admin-link-container');
    const mobileAdminLinkContainer = document.getElementById('mobile-admin-link-container');
    const authNotice = document.getElementById('booking-auth-notice');

    if (user) {
        if (guestBtns) guestBtns.classList.add('hidden');
        if (userProfile) userProfile.classList.remove('hidden');
        if (mobileGuest) mobileGuest.classList.add('hidden');
        if (mobileUser) mobileUser.classList.remove('hidden');

        // Populate user info
        const initials = user.name ? user.name.charAt(0).toUpperCase() : 'U';
        if (document.getElementById('user-avatar-initials')) {
            document.getElementById('user-avatar-initials').innerText = initials;
        }
        if (document.getElementById('mobile-user-avatar')) {
            document.getElementById('mobile-user-avatar').innerText = initials;
        }
        if (document.getElementById('nav-user-name')) {
            document.getElementById('nav-user-name').innerText = user.name;
        }
        if (document.getElementById('nav-user-email')) {
            document.getElementById('nav-user-email').innerText = user.email;
        }
        if (document.getElementById('nav-user-role')) {
            const roleLabels = { owner: '👑 เจ้าของร้าน', staff: '👨‍🍳 พนักงานหน้าร้าน', customer: '⭐ สมาชิก VIP' };
            document.getElementById('nav-user-role').innerText = roleLabels[user.role] || 'สมาชิก';
        }

        // Mobile info
        if (document.getElementById('mobile-user-name')) {
            document.getElementById('mobile-user-name').innerText = user.name;
        }
        if (document.getElementById('mobile-user-role')) {
            const roleLabels = { owner: '👑 เจ้าของร้าน', staff: '👨‍🍳 พนักงาน', customer: 'สมาชิก VIP' };
            document.getElementById('mobile-user-role').innerText = roleLabels[user.role] || 'สมาชิก';
        }

        // Booking section notice for logged-in member
        if (authNotice) {
            authNotice.innerHTML = `
                <div class="p-3.5 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-xs font-prompt mb-4">
                    <div class="flex items-center gap-2.5 text-emerald-300">
                        <i class="fa-solid fa-circle-check text-emerald-400 text-sm"></i>
                        <div>
                            <span class="text-gray-300">สมาชิกผู้จอง:</span> <strong class="text-white font-bold">${user.name}</strong> <span class="text-amber-400 font-normal">(${user.email})</span>
                        </div>
                    </div>
                    <span class="text-[11px] bg-emerald-900/80 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-700 font-semibold">สิทธิ์สมาชิกพร้อมใช้งาน</span>
                </div>
            `;
        }

        // Admin / Owner link in dropdown & mobile (เฉพาะ พนักงาน และ เจ้าของร้าน เท่านั้น)
        if (user.role === 'owner' || user.role === 'staff') {
            const roleLabel = user.role === 'owner' ? 'เจ้าของร้าน' : 'พนักงาน';
            if (adminLinkContainer) {
                adminLinkContainer.innerHTML = `
                    <button onclick="openOwnerControlModal()" class="w-full text-left flex items-center gap-2.5 px-4 py-2.5 text-sm text-amber-300 hover:bg-red-900/60 transition font-bold border-t border-red-900/40">
                        <i class="fa-solid fa-crown text-amber-400 w-4"></i> เมนูหลังบ้าน (${roleLabel})
                    </button>
                    <a href="admin.html" class="flex items-center gap-2.5 px-4 py-2 text-xs text-gray-300 hover:bg-red-900/50 hover:text-amber-300 transition">
                        <i class="fa-solid fa-gauge-high text-amber-400 w-4"></i> แดชบอร์ดหลังบ้านเต็มจอ
                    </a>
                `;
            }
            if (mobileAdminLinkContainer) {
                mobileAdminLinkContainer.innerHTML = `
                    <button onclick="toggleMobileMenu(); openOwnerControlModal()" class="w-full py-2.5 px-3 text-sm font-bold text-left text-amber-300 bg-red-900/60 border border-amber-500/50 rounded-xl flex items-center gap-2">
                        <i class="fa-solid fa-crown text-amber-400"></i> เมนูหลังบ้าน (${roleLabel})
                    </button>
                    <a href="admin.html" class="w-full py-2 px-3 text-xs text-left text-gray-300 hover:text-amber-300 bg-red-950/80 border border-red-900/50 rounded-xl flex items-center gap-2">
                        <i class="fa-solid fa-gauge-high text-amber-400"></i> แดชบอร์ดหลังบ้านเต็มจอ
                    </a>
                `;
            }
        } else {
            if (adminLinkContainer) adminLinkContainer.innerHTML = '';
            if (mobileAdminLinkContainer) mobileAdminLinkContainer.innerHTML = '';
        }

    } else {
        if (guestBtns) guestBtns.classList.remove('hidden');
        if (userProfile) userProfile.classList.add('hidden');
        if (mobileGuest) mobileGuest.classList.remove('hidden');
        if (mobileUser) mobileUser.classList.add('hidden');
        if (adminLinkContainer) adminLinkContainer.innerHTML = '';
        if (mobileAdminLinkContainer) mobileAdminLinkContainer.innerHTML = '';

        // Booking section notice for non-member / guest
        if (authNotice) {
            authNotice.innerHTML = `
                <div class="p-4 bg-red-950/70 border border-amber-500/50 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-prompt mb-4 shadow-lg">
                    <div class="flex items-center gap-3 text-amber-300">
                        <div class="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-base">
                            <i class="fa-solid fa-user-lock"></i>
                        </div>
                        <div>
                            <p class="font-bold text-white text-sm">ต้องสมัครสมาชิกเท่านั้นจึงจองคิวได้</p>
                            <p class="text-amber-200/80 text-[11px]">โปรดเข้าสู่ระบบหรือสมัครสมาชิกก่อนกดรับบัตรคิวออนไลน์</p>
                        </div>
                    </div>
                    <div class="flex gap-2 w-full sm:w-auto">
                        <button type="button" onclick="openAuthModal('login')" class="flex-1 sm:flex-initial px-3.5 py-2 bg-red-900/60 hover:bg-red-900 border border-amber-500/40 text-amber-300 rounded-xl transition font-semibold text-center">
                            เข้าสู่ระบบ
                        </button>
                        <button type="button" onclick="openAuthModal('register')" class="flex-1 sm:flex-initial px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 rounded-xl font-bold transition text-center shadow">
                            สมัครสมาชิก
                        </button>
                    </div>
                </div>
            `;
        }
    }
}

// Mobile Menu Toggle
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    if (menu) menu.classList.toggle('hidden');
}

// ---------------- SOUND & VOICE ANNOUNCEMENT (THAI FEMALE VOICE - QUEUE NUMBER ONLY) ----------------
function playChimeSound() {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        const audioCtx = new AudioContext();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5

        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + 0.6);
    } catch (e) {
        console.log('AudioContext error:', e);
    }
}

function announceQueueVoice(queueNumber) {
    playChimeSound();

    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        setTimeout(() => {
            const parts = queueNumber.split('-');
            const letter = parts[0];
            const numStr = parts[1] || '';
            const number = parseInt(numStr, 10) || numStr;

            const thaiLetterMap = { A: 'เอ', B: 'บี', C: 'ซี', V: 'วี ไอ พี' };
            const spokenLetter = thaiLetterMap[letter] || letter;

            // Voice announcement: Female Thai voice, queue number + ที่เคาน์เตอร์ (เช่น ขอเชิญหมายเลข A-012 ที่เคาน์เตอร์ค่ะ)
            const text = `ขอเชิญหมายเลข ${spokenLetter} ${number} ที่เคาน์เตอร์ค่ะ`;
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'th-TH';
            utterance.rate = 0.9;
            utterance.pitch = 1.2; // Female tone

            const voices = window.speechSynthesis.getVoices();
            const thaiVoice = voices.find(v => (v.lang === 'th-TH' || v.lang.startsWith('th')) && 
                (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('kanya') || 
                 v.name.toLowerCase().includes('narisa') || v.name.toLowerCase().includes('prem') || 
                 v.name.toLowerCase().includes('siri') || v.name.toLowerCase().includes('google')));
            if (thaiVoice) {
                utterance.voice = thaiVoice;
            } else {
                const anyThai = voices.find(v => v.lang === 'th-TH' || v.lang.startsWith('th'));
                if (anyThai) utterance.voice = anyThai;
            }

            window.speechSynthesis.speak(utterance);
        }, 400);
    }
}

// ---------------- USER PROFILE (ข้อมูลส่วนตัวของลูกค้า) ----------------
function openUserProfileModal() {
    const user = Store.getCurrentUser();
    if (!user) {
        openAuthModal('login');
        return;
    }

    const modal = document.getElementById('user-profile-modal');
    if (!modal) return;

    // Header info
    const initials = user.name ? user.name.charAt(0).toUpperCase() : 'U';
    const avatarEl = document.getElementById('profile-modal-avatar');
    if (avatarEl) avatarEl.innerText = initials;
    
    if (document.getElementById('profile-modal-name')) {
        document.getElementById('profile-modal-name').innerText = user.name;
    }
    if (document.getElementById('profile-modal-email')) {
        document.getElementById('profile-modal-email').innerText = user.email;
    }
    if (document.getElementById('profile-modal-phone')) {
        document.getElementById('profile-modal-phone').innerText = user.phone || '-';
    }
    if (document.getElementById('profile-modal-joined')) {
        document.getElementById('profile-modal-joined').innerText = user.created_at || '2026-02-10';
    }
    
    const roleLabels = { owner: '👑 เจ้าของร้าน', staff: '👨‍🍳 พนักงานหน้าร้าน', customer: '⭐ สมาชิก VIP' };
    if (document.getElementById('profile-modal-role-badge')) {
        document.getElementById('profile-modal-role-badge').innerText = roleLabels[user.role] || 'สมาชิก';
    }

    // Edit form defaults
    if (document.getElementById('profile-edit-name')) {
        document.getElementById('profile-edit-name').value = user.name || '';
    }
    if (document.getElementById('profile-edit-phone')) {
        document.getElementById('profile-edit-phone').value = user.phone || '';
    }
    if (document.getElementById('profile-edit-password')) {
        document.getElementById('profile-edit-password').value = '';
    }

    // Active queue & history
    renderUserProfileQueues(user);

    modal.classList.remove('hidden');
}

function closeUserProfileModal() {
    const modal = document.getElementById('user-profile-modal');
    if (modal) modal.classList.add('hidden');
}

function renderUserProfileQueues(user) {
    const queues = Store.getQueues();
    const userQueues = queues.filter(q => 
        (q.customerEmail && q.customerEmail.toLowerCase() === user.email.toLowerCase()) ||
        (q.customerPhone && user.phone && q.customerPhone === user.phone) ||
        (q.customerName && q.customerName === user.name)
    );

    const activeQueue = userQueues.find(q => q.status === 'waiting' || q.status === 'calling');
    const activeCard = document.getElementById('profile-active-queue-card');
    
    if (activeCard) {
        if (activeQueue) {
            const waitingAhead = queues.filter(q => q.type === activeQueue.type && q.status === 'waiting' && q.id !== activeQueue.id).length;
            const avgWait = Number(Store.getConfig().avgWaitPerQueueMinutes) || 6;
            const estWait = (waitingAhead + 1) * avgWait;
            const isCalling = activeQueue.status === 'calling';

            activeCard.innerHTML = `
                <div class="p-4 rounded-2xl bg-gradient-to-r from-red-950/80 to-[#120303] border-2 ${isCalling ? 'border-amber-400 animate-pulse' : 'border-red-800'} shadow-xl font-prompt space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-bold px-2.5 py-1 rounded-full ${isCalling ? 'bg-amber-500 text-slate-950 font-black' : 'bg-red-900/80 text-amber-300 border border-amber-500/30'}">
                            ${isCalling ? '🔥 กำลังเรียกคิวของคุณ!' : '⏳ กำลังรอคิว'}
                        </span>
                        <span class="text-xs text-gray-400">จองเวลา ${activeQueue.createdAt ? activeQueue.createdAt.substring(11, 16) : ''} น.</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-xs text-gray-400">หมายเลขคิว</p>
                            <p class="text-3xl font-black text-amber-400 font-kanit">${activeQueue.queueNumber}</p>
                        </div>
                        <div class="text-right">
                            <p class="text-xs text-gray-400">ประเภทโต๊ะ / จำนวน</p>
                            <p class="text-sm font-bold text-white">Type ${activeQueue.type} (${activeQueue.partySize} ท่าน)</p>
                            <p class="text-xs text-emerald-400 font-semibold">${isCalling ? 'เชิญที่จุดต้อนรับ' : `รออีก ~${estWait} นาที (${waitingAhead} คิวก่อนหน้า)`}</p>
                        </div>
                    </div>
                    <div class="pt-2 border-t border-red-900/50 flex gap-2">
                        <button onclick="closeUserProfileModal(); openTicketModalDirectly('${activeQueue.id}')" class="flex-1 py-2 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 text-white rounded-xl text-xs font-bold shadow">
                            <i class="fa-solid fa-qrcode mr-1"></i> ดูบัตรคิวดิจิทัล
                        </button>
                    </div>
                </div>
            `;
        } else {
            activeCard.innerHTML = `
                <div class="p-4 rounded-2xl bg-[#120303] border border-red-900/50 text-center font-prompt py-6">
                    <i class="fa-solid fa-ticket-simple text-gray-600 text-2xl mb-2"></i>
                    <p class="text-xs text-gray-400">ขณะนี้คุณไม่มีคิวที่กำลังรอรับบริการ</p>
                    <a href="#queue-section" onclick="closeUserProfileModal()" class="inline-block mt-3 px-4 py-2 bg-red-900/60 hover:bg-red-900 border border-amber-500/40 text-amber-300 rounded-xl text-xs font-bold transition">
                        <i class="fa-solid fa-plus mr-1"></i> จองคิวทานที่ร้านตอนนี้
                    </a>
                </div>
            `;
        }
    }

    const historyContainer = document.getElementById('profile-queue-history-list');
    if (historyContainer) {
        const historyQueues = userQueues.filter(q => q.status === 'seated' || q.status === 'completed' || q.status === 'cancelled');
        if (historyQueues.length === 0) {
            historyContainer.innerHTML = `<p class="text-xs text-gray-500 text-center py-3">ยังไม่มีประวัติการจองคิวก่อนหน้า</p>`;
        } else {
            const statusMap = {
                seated: { text: 'เข้ารับบริการแล้ว', color: 'text-blue-400' },
                completed: { text: 'เสร็จสิ้น', color: 'text-emerald-400' },
                cancelled: { text: 'ยกเลิก / ข้ามคิว', color: 'text-gray-400' }
            };
            historyContainer.innerHTML = historyQueues.slice(0, 5).map(q => `
                <div class="p-2.5 rounded-xl bg-[#0f0202] border border-red-950 flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-amber-300">${q.queueNumber}</span>
                        <span class="text-gray-400">(${q.partySize} ท่าน)</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-gray-500">${q.createdAt ? q.createdAt.substring(0, 10) : ''}</span>
                        <span class="font-semibold ${statusMap[q.status]?.color || 'text-gray-400'}">${statusMap[q.status]?.text || q.status}</span>
                    </div>
                </div>
            `).join('');
        }
    }
}

function handleUpdateUserProfile(e) {
    e.preventDefault();
    const currentUser = Store.getCurrentUser();
    if (!currentUser) return;

    const newName = document.getElementById('profile-edit-name').value.trim();
    const newPhone = document.getElementById('profile-edit-phone').value.trim();
    const newPass = document.getElementById('profile-edit-password').value;

    if (!newName || !newPhone) {
        showToast('ข้อมูลไม่ครบ', 'กรุณากรอกชื่อและเบอร์โทรศัพท์', 'warning');
        return;
    }

    currentUser.name = newName;
    currentUser.phone = newPhone;
    if (newPass && newPass.length >= 6) {
        currentUser.password = newPass;
    }

    // Save to Store
    Store.setCurrentUser(currentUser);
    const users = Store.getUsers();
    const uIdx = users.findIndex(u => u.id === currentUser.id);
    if (uIdx !== -1) {
        users[uIdx].name = newName;
        users[uIdx].phone = newPhone;
        if (newPass && newPass.length >= 6) {
            users[uIdx].password = newPass;
        }
        Store.saveUsers(users);
    }

    checkCurrentUserStatus();
    openUserProfileModal();
    showToast('บันทึกสำเร็จ!', 'อัปเดตข้อมูลส่วนตัวของคุณเรียบร้อยแล้ว', 'success');
}

// ---------------- OWNER WEB CONTROL MODAL (จัดการระบบร้านสำหรับเจ้าของร้านบนหน้าเว็บ) ----------------
let currentOwnerTab = 'queues';

function openOwnerControlModal(tab = 'queues') {
    const user = Store.getCurrentUser();
    if (!user || (user.role !== 'owner' && user.role !== 'staff')) {
        showToast('ไม่มีสิทธิ์เข้าถึง', 'เมนูหลังบ้านนี้สงวนสิทธิ์เฉพาะพนักงานและเจ้าของร้านเท่านั้น', 'warning');
        openAuthModal('login');
        return;
    }

    const modal = document.getElementById('owner-control-modal');
    if (!modal) return;

    const roleBadge = document.getElementById('owner-modal-role-badge');
    if (roleBadge) {
        roleBadge.innerText = user.role === 'owner' ? '👑 สิทธิ์: เจ้าของร้าน (Owner)' : '👨‍🍳 สิทธิ์: พนักงานหน้าร้าน (Staff)';
    }

    modal.classList.remove('hidden');
    switchOwnerTab(tab);
}

function closeOwnerControlModal() {
    const modal = document.getElementById('owner-control-modal');
    if (modal) modal.classList.add('hidden');
}

function switchOwnerTab(tabName) {
    currentOwnerTab = tabName;
    const tabs = ['queues', 'tables', 'promos', 'users', 'settings'];

    tabs.forEach(t => {
        const btn = document.getElementById(`owner-tab-btn-${t}`);
        const content = document.getElementById(`owner-tab-${t}`);
        if (btn && content) {
            if (t === tabName) {
                btn.className = 'owner-tab-btn active px-3.5 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 border border-amber-400 transition flex items-center gap-1.5';
                content.classList.remove('hidden');
            } else {
                btn.className = 'owner-tab-btn px-3.5 py-1.5 rounded-xl text-xs font-medium bg-red-950/70 text-gray-300 hover:text-amber-300 border border-red-900 transition flex items-center gap-1.5';
                content.classList.add('hidden');
            }
        }
    });

    if (tabName === 'queues') renderOwnerQueues();
    if (tabName === 'tables') renderOwnerTables();
    if (tabName === 'promos') renderOwnerPromotions();
    if (tabName === 'users') renderOwnerUsers();
    if (tabName === 'settings') renderOwnerSettings();
}

function renderOwnerQueues() {
    const tbody = document.getElementById('owner-queues-tbody');
    if (!tbody) return;

    const queues = Store.getQueues();
    const activeQueues = queues.filter(q => q.status === 'waiting' || q.status === 'calling');

    if (activeQueues.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-8 text-gray-500">
                    <i class="fa-solid fa-check-double text-2xl text-emerald-500 mb-2 block"></i>
                    ขณะนี้ไม่มีคิวที่กำลังรอเรียก
                </td>
            </tr>
        `;
        return;
    }

    const statusBadge = {
        calling: '<span class="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-black animate-pulse">กำลังเรียก</span>',
        waiting: '<span class="px-2 py-0.5 rounded bg-red-900/70 text-amber-300 border border-red-700">รอคิว</span>'
    };

    tbody.innerHTML = activeQueues.map(q => `
        <tr class="hover:bg-red-950/40 transition">
            <td class="py-2.5 px-3 font-bold text-amber-400 font-kanit text-sm">${q.queueNumber}</td>
            <td class="py-2.5 px-3">
                <span class="text-white font-medium">${q.customerName || 'ลูกค้า'}</span>
                <span class="text-[10px] text-gray-400 block">${q.customerPhone && q.customerPhone !== '-' ? q.customerPhone : ''}</span>
            </td>
            <td class="py-2.5 px-3 text-gray-300">Type ${q.type} (${q.partySize} ท่าน)</td>
            <td class="py-2.5 px-3">${statusBadge[q.status] || q.status}</td>
            <td class="py-2.5 px-3 text-gray-400 text-[11px]">${q.createdAt ? q.createdAt.substring(11, 16) : ''} น.</td>
            <td class="py-2.5 px-3 text-right">
                <div class="flex items-center justify-end gap-1.5">
                    <button onclick="ownerCallQueue('${q.id}')" class="px-2.5 py-1 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow" title="เรียกคิวด้วยเสียงภาษาไทย">
                        <i class="fa-solid fa-bullhorn text-[11px]"></i> เรียกคิว
                    </button>
                    <button onclick="ownerSeatQueue('${q.id}')" class="px-2 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs transition" title="จัดโต๊ะ">
                        <i class="fa-solid fa-chair text-[11px]"></i> จัดโต๊ะ
                    </button>
                    <button onclick="ownerSkipQueue('${q.id}')" class="px-2 py-1 bg-red-950 hover:bg-red-900 text-amber-300 border border-red-800 rounded-lg text-xs transition" title="ข้ามคิว">
                        <i class="fa-solid fa-forward-step text-[11px]"></i> ข้าม
                    </button>
                    <button onclick="ownerDeleteQueue('${q.id}')" class="p-1 text-gray-400 hover:text-red-400 transition" title="ลบคิว">
                        <i class="fa-solid fa-trash text-xs"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

function ownerCallQueue(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (!q) return;

    q.status = 'calling';
    q.calledAt = new Date().toISOString().replace('T', ' ').substring(0, 19);
    Store.saveQueues(queues);

    renderOwnerQueues();
    updateLiveBoardSummary();

    // Voice announcement (Female Thai voice, ONLY queue number)
    announceQueueVoice(q.queueNumber);
    showToast('กำลังเรียกคิว', `เรียกคิวหมายเลข ${q.queueNumber} แล้ว`, 'info');
}

function ownerRepeatCallQueue(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (q) {
        announceQueueVoice(q.queueNumber);
        showToast('เรียกคิวซ้ำ', `เรียกหมายเลข ${q.queueNumber} อีกครั้ง`, 'info');
    }
}

function ownerSeatQueue(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (!q) return;

    const tables = Store.getTables();
    const available = tables.find(t => t.type === q.type && t.status === 'available') || tables.find(t => t.status === 'available');

    q.status = 'seated';
    if (available) {
        q.tableId = available.id;
        available.status = 'occupied';
        available.currentQueue = q.queueNumber;
        Store.saveTables(tables);
    }

    Store.saveQueues(queues);
    renderOwnerQueues();
    updateLiveBoardSummary();
    showToast('จัดโต๊ะสำเร็จ', `คิว ${q.queueNumber} จัดนั่งโต๊ะเรียบร้อยแล้ว`, 'success');
}

function ownerSkipQueue(queueId) {
    if (!confirm('ยืนยันการข้ามคิวนี้ (ลูกค้าไม่มาแสดงตัว)?')) return;
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (q) {
        q.status = 'cancelled';
        Store.saveQueues(queues);
        renderOwnerQueues();
        updateLiveBoardSummary();
        showToast('ข้ามคิวแล้ว', `คิว ${q.queueNumber} ถูกปรับสถานะเป็นข้ามคิว`, 'warning');
    }
}

function ownerDeleteQueue(queueId) {
    if (!confirm('ต้องการลบคิวนี้ใช่หรือไม่?')) return;
    let queues = Store.getQueues();
    queues = queues.filter(q => q.id !== queueId);
    Store.saveQueues(queues);
    renderOwnerQueues();
    updateLiveBoardSummary();
    showToast('ลบสำเร็จ', 'ลบข้อมูลคิวเรียบร้อยแล้ว', 'info');
}

// Walk-in modal
function openWalkinModalOnFront() {
    const modal = document.getElementById('front-walkin-modal');
    if (modal) modal.classList.remove('hidden');
}

function closeFrontWalkinModal() {
    const modal = document.getElementById('front-walkin-modal');
    if (modal) modal.classList.add('hidden');
}

function handleOwnerWalkinBooking(e) {
    e.preventDefault();
    const name = document.getElementById('front-walkin-name').value.trim();
    const phone = document.getElementById('front-walkin-phone').value.trim() || '-';
    const partySize = document.getElementById('front-walkin-party-size').value;
    const notes = document.getElementById('front-walkin-notes').value.trim();

    let prefix = 'A';
    if (partySize === '3-4') prefix = 'B';
    if (partySize === '5-8') prefix = 'C';
    if (partySize === '9+') prefix = 'V';

    const queues = Store.getQueues();
    const currentPrefixQueues = queues.filter(q => q.type === prefix);
    let nextNum = 1;
    if (currentPrefixQueues.length > 0) {
        const highest = currentPrefixQueues.reduce((max, q) => {
            const num = parseInt(q.queueNumber.split('-')[1]) || 0;
            return num > max ? num : max;
        }, 0);
        nextNum = highest + 1;
    }
    const queueNumber = `${prefix}-${String(nextNum).padStart(3, '0')}`;

    const newQueue = {
        id: 'q-walkin-' + Date.now(),
        queueNumber: queueNumber,
        type: prefix,
        partySize: partySize,
        customerName: name || 'ลูกค้า Walk-in',
        customerPhone: phone,
        customerEmail: '',
        branch: 'siam',
        soup: 'mala-classic',
        notes: notes ? `[Walk-in] ${notes}` : '[Walk-in หน้าร้าน]',
        status: 'waiting',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        calledAt: null,
        tableId: null
    };

    queues.push(newQueue);
    Store.saveQueues(queues);

    closeFrontWalkinModal();
    renderOwnerQueues();
    updateLiveBoardSummary();
    showToast('ออกบัตรคิวสำเร็จ!', `ออกบัตรคิว Walk-in หมายเลข ${queueNumber} เรียบร้อยแล้ว`, 'success');
}

// Table Management
function renderOwnerTables() {
    const container = document.getElementById('owner-tables-grid');
    if (!container) return;

    const tables = Store.getTables();
    const statusMap = {
        available: { text: 'ว่าง', badge: 'bg-emerald-950 text-emerald-400 border-emerald-700', border: 'border-emerald-500/40' },
        occupied: { text: 'มีลูกค้า', badge: 'bg-red-950 text-red-400 border-red-700', border: 'border-red-500/40' },
        calling: { text: 'เรียกคิว', badge: 'bg-amber-950 text-amber-300 border-amber-700', border: 'border-amber-500/40' },
        cleaning: { text: 'ทำความส��อาด', badge: 'bg-blue-950 text-blue-400 border-blue-700', border: 'border-blue-500/40' }
    };

    container.innerHTML = tables.map(t => {
        const st = statusMap[t.status] || statusMap.available;
        return `
            <div class="p-3 bg-[#110303] border ${st.border} rounded-2xl flex flex-col justify-between space-y-2">
                <div class="flex items-center justify-between">
                    <span class="font-bold text-white text-xs font-kanit">${t.name}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded border ${st.badge}">${st.text}</span>
                </div>
                <div class="text-[11px] text-gray-400">
                    <p>${t.seats} ที่นั่ง (Type ${t.type})</p>
                    <p class="text-amber-300 font-semibold">${t.currentQueue ? `คิว: ${t.currentQueue}` : 'ไม่มีคิวนั่ง'}</p>
                </div>
                <div class="pt-2 border-t border-red-950 flex gap-1">
                    ${t.status === 'occupied' ? `
                        <button onclick="ownerClearTable('${t.id}')" class="flex-1 py-1 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 rounded-lg text-[10px] font-bold">
                            เคลียร์โต๊ะ
                        </button>
                    ` : t.status === 'cleaning' ? `
                        <button onclick="ownerChangeTableStatus('${t.id}', 'available')" class="flex-1 py-1 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 rounded-lg text-[10px] font-bold">
                            พร้อมใช้
                        </button>
                    ` : `
                        <button onclick="ownerChangeTableStatus('${t.id}', 'cleaning')" class="flex-1 py-1 bg-blue-950 hover:bg-blue-900 text-blue-300 rounded-lg text-[10px]">
                            ทำความสะอาด
                        </button>
                    `}
                </div>
            </div>
        `;
    }).join('');
}

function ownerClearTable(tableId) {
    const tables = Store.getTables();
    const tbl = tables.find(t => t.id === tableId);
    if (tbl) {
        tbl.status = 'available';
        tbl.currentQueue = null;
        Store.saveTables(tables);
        renderOwnerTables();
        showToast('เคลียร์โต๊ะสำเร็จ', `โต๊ะ ${tbl.name} เป��ี่ยนสถานะเป็นว่างแล้ว`, 'success');
    }
}

function ownerChangeTableStatus(tableId, newStatus) {
    const tables = Store.getTables();
    const tbl = tables.find(t => t.id === tableId);
    if (tbl) {
        tbl.status = newStatus;
        if (newStatus === 'available') tbl.currentQueue = null;
        Store.saveTables(tables);
        renderOwnerTables();
        showToast('เปลี่ยนสถานะสำเร็จ', `โต๊ะ ${tbl.name} เปลี่ยนสถานะเป็น ${newStatus}`, 'info');
    }
}

// Promotions Management
function renderOwnerPromotions() {
    const container = document.getElementById('owner-promos-grid');
    if (!container) return;

    const promos = Store.getPromotions();
    container.innerHTML = promos.map(p => `
        <div class="p-3 bg-[#110303] border border-red-900/60 rounded-2xl flex items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <img src="${p.image}" alt="" class="w-12 h-12 rounded-xl object-cover">
                <div>
                    <h5 class="text-xs font-bold text-white font-kanit">${p.title}</h5>
                    <span class="text-[10px] text-amber-400">${p.discount} • ${p.period}</span>
                </div>
            </div>
            <button onclick="ownerDeletePromo('${p.id}')" class="p-2 text-gray-400 hover:text-red-400 transition" title="ลบโปรโมชั่น">
                <i class="fa-solid fa-trash text-xs"></i>
            </button>
        </div>
    `).join('');
}

function toggleOwnerPromoForm() {
    const f = document.getElementById('owner-promo-form-container');
    if (f) f.classList.toggle('hidden');
}

function handleOwnerAddPromo(e) {
    e.preventDefault();
    const title = document.getElementById('owner-promo-title').value.trim();
    const category = document.getElementById('owner-promo-category').value;
    const discount = document.getElementById('owner-promo-discount').value.trim() || 'โปรโมชั่นพิเศษ';
    const period = document.getElementById('owner-promo-period').value.trim() || 'ตลอดปี 2026';
    const image = document.getElementById('owner-promo-image').value.trim() || 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?q=80&w=800&auto=format&fit=crop';
    const desc = document.getElementById('owner-promo-desc').value.trim() || '';

    const promos = Store.getPromotions();
    promos.unshift({
        id: 'promo-' + Date.now(),
        title,
        category,
        tag: 'SPECIAL PROMO',
        discount,
        period,
        desc,
        image,
        code: 'MALA' + Math.floor(1000 + Math.random() * 9000),
        featured: true
    });

    Store.savePromotions(promos);
    toggleOwnerPromoForm();
    renderOwnerPromotions();
    renderPromotions('all');
    showToast('เพิ่มโปรโมชั่นสำเร็จ', `เพิ่ม "${title}" เรียบร้อยแล้ว`, 'success');
}

function ownerDeletePromo(promoId) {
    if (!confirm('ต้องการลบโปรโมชั่นนี้ใช่หรือไม่?')) return;
    let promos = Store.getPromotions();
    promos = promos.filter(p => p.id !== promoId);
    Store.savePromotions(promos);
    renderOwnerPromotions();
    renderPromotions('all');
    showToast('ลบสำเร็จ', 'ลบโปรโมชั่นเรียบร้อยแล้ว', 'info');
}

// User Accounts Management
function renderOwnerUsers() {
    const tbody = document.getElementById('owner-users-tbody');
    if (!tbody) return;

    const users = Store.getUsers();
    const roleBadges = {
        owner: '<span class="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold">👑 เจ้าของร้าน</span>',
        staff: '<span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">👨‍🍳 พนักงาน</span>',
        customer: '<span class="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold">👤 สมาชิก VIP</span>'
    };

    tbody.innerHTML = users.map(u => `
        <tr class="hover:bg-red-950/40 transition">
            <td class="py-2.5 px-3 font-bold text-white">${u.name}</td>
            <td class="py-2.5 px-3 text-amber-300 font-mono text-[11px]">${u.email}</td>
            <td class="py-2.5 px-3 text-gray-300">${u.phone || '-'}</td>
            <td class="py-2.5 px-3">${roleBadges[u.role] || u.role}</td>
            <td class="py-2.5 px-3 text-right">
                ${u.role !== 'owner' ? `
                    <button onclick="ownerDeleteUser('${u.id}')" class="p-1 text-gray-400 hover:text-red-400 transition" title="ลบผู้ใช้">
                        <i class="fa-solid fa-trash text-xs"></i>
                    </button>
                ` : '<span class="text-[10px] text-gray-500">เจ้าของระบบ</span>'}
            </td>
        </tr>
    `).join('');
}

function toggleOwnerUserForm() {
    const f = document.getElementById('owner-user-form-container');
    if (f) f.classList.toggle('hidden');
}

function handleOwnerAddUser(e) {
    e.preventDefault();
    const name = document.getElementById('owner-user-name').value.trim();
    const email = document.getElementById('owner-user-email').value.trim().toLowerCase();
    const phone = document.getElementById('owner-user-phone').value.trim();
    const role = document.getElementById('owner-user-role').value;
    const password = document.getElementById('owner-user-password').value;

    const users = Store.getUsers();
    if (users.find(u => u.email.toLowerCase() === email)) {
        showToast('อีเมลซ้ำ', 'อีเมลนี้ถูกใช้งานแล้วในระบบ', 'warning');
        return;
    }

    users.push({
        id: 'u-' + Date.now(),
        name,
        email,
        phone,
        password,
        role,
        created_at: new Date().toISOString().substring(0, 10)
    });

    Store.saveUsers(users);
    toggleOwnerUserForm();
    renderOwnerUsers();
    showToast('เพิ่มผู้ใช้สำเร็จ', `เพิ่ม ${name} (${role}) เรียบร้อยแล้ว`, 'success');
}

function ownerDeleteUser(userId) {
    if (!confirm('ต้องการลบผู้ใช้งานนี้ใช่หรือไม่?')) return;
    let users = Store.getUsers();
    users = users.filter(u => u.id !== userId);
    Store.saveUsers(users);
    renderOwnerUsers();
    showToast('ลบสำเร็จ', 'ลบผู้ใช้เรียบร้อยแล้ว', 'info');
}

// Store Settings
function renderOwnerSettings() {
    const cfg = Store.getConfig();
    if (!cfg) return;

    if (document.getElementById('owner-setting-name')) {
        document.getElementById('owner-setting-name').value = cfg.storeName || 'DRAGON MALA HOTPOT';
    }
    if (document.getElementById('owner-setting-queue-open')) {
        document.getElementById('owner-setting-queue-open').checked = cfg.isQueueOpen !== false;
    }
    if (document.getElementById('owner-setting-avg-wait')) {
        document.getElementById('owner-setting-avg-wait').value = cfg.avgWaitPerQueueMinutes || 6;
    }
    if (document.getElementById('owner-setting-announcement')) {
        document.getElementById('owner-setting-announcement').value = cfg.announcement || '';
    }
}

function handleOwnerSaveSettings(e) {
    e.preventDefault();
    const storeName = document.getElementById('owner-setting-name').value.trim();
    const isQueueOpen = document.getElementById('owner-setting-queue-open').checked;
    const avgWait = parseInt(document.getElementById('owner-setting-avg-wait').value) || 6;
    const announcement = document.getElementById('owner-setting-announcement').value.trim();

    const cfg = {
        ...Store.getConfig(),
        storeName: storeName || 'DRAGON MALA HOTPOT',
        isQueueOpen,
        avgWaitPerQueueMinutes: avgWait,
        openHours: '11:00 - 02:00 น.',
        announcement
    };

    Store.saveConfig(cfg);
    renderStoreIdentity();
    renderQueueBookingState();
    showToast('บันทึกสำเร็จ!', 'การตั้งค่าระบบร้านได้รับการบันทึกแล้ว', 'success');
}

function openTicketModalDirectly(queueId) {
    const queues = Store.getQueues();
    const q = queues.find(item => item.id === queueId);
    if (!q) return;

    const waitingBefore = queues.filter(item => item.type === q.type && item.status === 'waiting' && item.id !== q.id).length;
    const avgWait = Number(Store.getConfig().avgWaitPerQueueMinutes) || 6;
    const estWaitMinutes = (waitingBefore + 1) * avgWait;

    if (document.getElementById('ticket-queue-number')) {
        document.getElementById('ticket-queue-number').innerText = q.queueNumber;
    }
    if (document.getElementById('ticket-customer-name')) {
        document.getElementById('ticket-customer-name').innerText = q.customerName || 'สมาชิก';
    }
    if (document.getElementById('ticket-party-size')) {
        document.getElementById('ticket-party-size').innerText = q.partySize + ' ท่าน';
    }
    if (document.getElementById('ticket-table-type')) {
        const typeLabels = { '1-2': 'โต๊ะเล็ก (Type A)', '3-4': 'โต๊ะกลาง (Type B)', '5-8': 'โต๊ะใหญ่ (Type C)', '9+': 'ห้อง VIP (Type V)' };
        document.getElementById('ticket-table-type').innerText = typeLabels[q.partySize] || `Type ${q.type}`;
    }
    if (document.getElementById('ticket-ahead-count')) {
        document.getElementById('ticket-ahead-count').innerText = waitingBefore + ' คิว';
    }
    if (document.getElementById('ticket-est-time')) {
        document.getElementById('ticket-est-time').innerText = `~${estWaitMinutes} นาที`;
    }

    if (document.getElementById('ticket-modal')) {
        document.getElementById('ticket-modal').classList.remove('hidden');
    }
}
