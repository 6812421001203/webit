import http.server
import socketserver
import webbrowser
import os
import json
import sqlite3
from urllib.parse import parse_qs, urlparse

DIRECTORY = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "8000"))
DATABASE = os.environ.get(
    "DRAGON_MALA_DATABASE",
    os.path.join(DIRECTORY, "dragon_mala.db"),
)
STORE_KEYS = {
    "dragon_mala_queues",
    "dragon_mala_users",
    "dragon_mala_promotions",
    "dragon_mala_menus",
    "dragon_mala_soups",
    "dragon_mala_tables",
    "dragon_mala_config",
}


def initialize_database():
    with sqlite3.connect(DATABASE) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS store_values (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def read_store_value(key):
    with sqlite3.connect(DATABASE) as connection:
        row = connection.execute(
            "SELECT value FROM store_values WHERE key = ?", (key,)
        ).fetchone()
    return json.loads(row[0]) if row else None


def write_store_value(key, value):
    serialized = json.dumps(value, ensure_ascii=False)
    with sqlite3.connect(DATABASE) as connection:
        connection.execute(
            """
            INSERT INTO store_values (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = CURRENT_TIMESTAMP
            """,
            (key, serialized),
        )

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/store":
            key = parse_qs(parsed.query).get("key", [None])[0]
            if key not in STORE_KEYS:
                self.send_error(400, "Unknown store key")
                return

            value = read_store_value(key)
            if value is None:
                self.send_error(404, "Store value not found")
                return
            self._send_json({"value": value})
            return
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/store":
            self.send_error(404)
            return

        key = parse_qs(parsed.query).get("key", [None])[0]
        if key not in STORE_KEYS:
            self.send_error(400, "Unknown store key")
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length))
            write_store_value(key, payload["value"])
        except (ValueError, KeyError, json.JSONDecodeError):
            self.send_error(400, "Invalid JSON payload")
            return

        self._send_json({"ok": True})

    def _send_json(self, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

def run():
    initialize_database()
    os.chdir(DIRECTORY)
    server_class = getattr(socketserver, "ThreadingTCPServer")
    with server_class(("", PORT), Handler) as httpd:
        print(f"🔥 DRAGON MALA Web Server is running at http://localhost:{PORT}")
        print(f"👉 Client Home: /index.html")
        print(f"👉 Backoffice:  /admin.html")
        if os.environ.get("DRAGON_MALA_OPEN_BROWSER") == "1":
            webbrowser.open(f"http://localhost:{PORT}/index.html")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")

if __name__ == '__main__':
    run()
