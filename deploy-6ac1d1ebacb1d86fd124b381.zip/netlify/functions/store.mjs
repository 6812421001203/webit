import { getStore } from "@netlify/blobs";

const ALLOWED_KEYS = new Set([
  "dragon_mala_queues",
  "dragon_mala_users",
  "dragon_mala_promotions",
  "dragon_mala_menus",
  "dragon_mala_soups",
  "dragon_mala_tables",
  "dragon_mala_config"
]);

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};

function response(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers });
}

export default async function handler(request) {
  const key = new URL(request.url).searchParams.get("key");
  if (!ALLOWED_KEYS.has(key)) {
    return response({ error: "Unknown store key" }, 400);
  }

  const store = getStore("dragon-mala-store");

  if (request.method === "GET") {
    const value = await store.get(key, { type: "json" });
    if (value === null) return response({ error: "Store value not found" }, 404);
    return response({ value });
  }

  if (request.method === "POST") {
    let payload;
    try {
      payload = await request.json();
    } catch {
      return response({ error: "Invalid JSON payload" }, 400);
    }

    if (!Object.prototype.hasOwnProperty.call(payload, "value")) {
      return response({ error: "Missing value" }, 400);
    }

    await store.setJSON(key, payload.value);
    return response({ ok: true });
  }

  return response({ error: "Method not allowed" }, 405);
}
